import 'package:flutter/foundation.dart';


class SplashController extends ChangeNotifier{

}