# local deploy

Run

```bash
flutter pub get
```

```bash
dart run build_runner build
```

```bash
flutter build appbundle
```
```bash
flutter build ios --debug --simulator
```