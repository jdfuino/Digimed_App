import 'package:flutter/material.dart';

class BannerCreatePatient extends StatelessWidget {
  const BannerCreatePatient({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
