import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/icons/digimed_icon_icons.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/medicine_controller.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class FormNewMedicine extends StatefulWidget {
  const FormNewMedicine({super.key});

  @override
  _FormNewMedicineState createState() => _FormNewMedicineState();
}

class _FormNewMedicineState extends State<FormNewMedicine> {
  final TextEditingController medicineController = TextEditingController();
  final TextEditingController concentrationController = TextEditingController();
  final TextEditingController unitController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  String unit = 'mg';

  @override
  void dispose() {
    medicineController.dispose();
    concentrationController.dispose();
    unitController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final MedicineController controller = context.watch<MedicineController>();
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Builder(builder: (contextF) {
        return Dialog(
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(12.0),
            ),
          ),
          child: SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.only(
                  top: 12, right: 14, left: 14, bottom: 32),
              decoration: const BoxDecoration(color: Colors.white),
              child: Container(
                margin: const EdgeInsets.only(right: 14, left: 14),
                child: Form(
                  child: Builder(builder: (formContext) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            const Spacer(),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: AppColors.backgroundColor,
                              ),
                              child: IconButton(
                                onPressed: () {
                                  Navigator.of(context).pop(false);
                                },
                                icon: Icon(
                                  Icons.close,
                                  color: AppColors.scaffoldBackgroundColor,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Icon(
                          DigimedIcon.add_doctor,
                          color: AppColors.backgroundSettingSaveColor,
                          size: 80,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Agregar Medicamentos",
                          style: AppTextStyle.boldContentTextStyle,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller:
                              medicineController, // Asigna el controlador
                          keyboardType: TextInputType.text,
                          style: AppTextStyle.normalTextStyle2,
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: AppColors.backgroundSearchColor,
                            hintText: 'Ingresa el medicamento',
                            hintStyle: AppTextStyle.hintTextStyle,
                            contentPadding: const EdgeInsets.fromLTRB(
                                20.0, 15.0, 20.0, 15.0),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                  width: 0.2,
                                  color: AppColors.backgroundSearchColor),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Por favor ingrese el nombre de la medicina';
                            }
                          },
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller:
                                    concentrationController, // Controlador para la concentración
                                keyboardType: TextInputType.number,
                                style: AppTextStyle.normalTextStyle2,
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: AppColors.backgroundSearchColor,
                                  hintText: 'Concentración',
                                  hintStyle: AppTextStyle.hintTextStyle,
                                  contentPadding: const EdgeInsets.fromLTRB(
                                      20.0, 15.0, 20.0, 15.0),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: const BorderSide(
                                        width: 0.2,
                                        color: AppColors.backgroundSearchColor),
                                  ),
                                ),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Por favor ingrese la concentracion';
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 5),
                            _dropMenuMedicine(context),
                          ],
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          controller:
                              descriptionController, // Controlador para la descripción
                          keyboardType: TextInputType.text,
                          style: AppTextStyle.normalTextStyle2,
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: AppColors.backgroundSearchColor,
                            hintText: 'Descripción (opcional)',
                            hintStyle: AppTextStyle.hintTextStyle,
                            contentPadding: const EdgeInsets.fromLTRB(
                                20.0, 15.0, 20.0, 15.0),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: const BorderSide(
                                  width: 0.2,
                                  color: AppColors.backgroundSearchColor),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () {
                            final newMedicine = Medicine(
                              name: medicineController.text,
                              concentration: concentrationController.text,
                              unit: unit,
                              description: descriptionController.text,
                            );
                            controller.addMedicine(newMedicine);
                            Navigator.of(context).pop();
                          },
                          child: const Text("Guardar"),
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _dropMenuMedicine(BuildContext context) {
    return PopupMenuButton<String>(
      onSelected: (String value) {
        setState(() {
          unit = value;
        });
      },
      itemBuilder: (BuildContext context) {
        return ["g", "mg"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList();
      },
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: <Widget>[
              const Icon(Icons.arrow_drop_down,
                  color: AppColors.backgroundColor),
              Text(unit, style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(width: 8)
            ],
          ),
        ),
      ),
    );
  }
}
