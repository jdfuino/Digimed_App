import 'package:digimed/app/domain/models/location_input/location_input.dart';
import 'package:digimed/app/domain/models/patients/patients.dart';
import 'package:digimed/app/domain/models/user/user.dart';
import 'package:digimed/app/domain/repositories/accountRepository.dart';
import 'package:digimed/app/domain/repositories/position_repository.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/global/state_notifier.dart';
import 'package:digimed/app/presentation/global/widgets/request_location_patient_dialog.dart';
import 'package:digimed/app/presentation/pages/home/patient/controller/state/home_patient_state.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

class HomePatientController extends StateNotifier<HomePatientState> {
  final AccountRepository accountRepository;
  final SessionController sessionController;
  final PositionRepository positionRepository;
  Patients patients;
  final BuildContext context;
  Position? positionPatient;

  HomePatientController(super.state,
      {required this.accountRepository,
      required this.sessionController,
      required this.positionRepository,
      required this.context,
      required this.patients});

  Future<void> init() async {
    await refreshMePatient();
    await checkPosition();
  }

  void showRequestLocationDialog() {
    showDialog(
        context: context,
        builder: (context) => RequestLocationPatientDialog(
              onFinish: () async {
                await checkPositionDialog();
              },
            ));
  }

  Future<void> checkPosition() async {
    if (await positionRepository.checkServiceLocation()) {
      LocationPermission permission =
          await positionRepository.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        print("location permission denied");
        showRequestLocationDialog();
        //permission = await positionRepository.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          print("location permission denied again");
          //showRequestLocationDialog();
        } else {
          positionPatient = await positionRepository.getCurrentLocation();
          if (positionPatient != null) {
            await uploadNewRecord();
          }
        }
      } else if (permission == LocationPermission.deniedForever) {
        print("location permission denied for ever");
      } else {
        positionPatient = await positionRepository.getCurrentLocation();
        if (positionPatient != null) {
          await uploadNewRecord();
        }
      }
    } else {
      print("location service disable");
    }
  }

  Future<void> checkPositionDialog() async {
    if (await positionRepository.checkServiceLocation()) {
      LocationPermission permission =
          await positionRepository.checkPermission();
      if (permission == LocationPermission.denied) {
        print("location permission denied");
        permission = await positionRepository.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          print("location permission denied again");
          //showRequestLocationDialog();
        } else {
          positionPatient = await positionRepository.getCurrentLocation();
          if (positionPatient != null) {
            await uploadNewRecord();
          }
        }
      } else if (permission == LocationPermission.deniedForever) {
        print("location permission denied for ever");
      } else {
        positionPatient = await positionRepository.getCurrentLocation();
        if (positionPatient != null) {
          await uploadNewRecord();
        }
      }
    } else {
      print("location service disable");
    }
  }

  Future<void> uploadNewRecord() async {
    LocationInput locationInput = LocationInput(
        userID: sessionController.patients!.user.id,
        latitude: positionPatient!.latitude,
        longitude: positionPatient!.longitude);
    final result = await accountRepository.recordNewLocation(locationInput);

    result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            showToast("Sesion expirada");
            sessionController.globalCloseSession();
          },
          orElse: () {});
    }, right: (_) {
      print("Location update");
    });
  }

  Future<void> refreshMePatient(
      {AssociatePatientPatients? associatePatientPatients}) async {
    if (associatePatientPatients != null) {
      state = state.copyWith(associatePatients: associatePatientPatients);
    }
    final result = await accountRepository.getMePatient(patients.user);
    state = result.when(
        left: (failed) {
          failed.maybeWhen(
              tokenInvalided: () {
                showToast("Sesion expirada");
                sessionController.globalCloseSession();
              },
              orElse: () {});
          return state.copyWith(
              associatePatients: const AssociatePatientPatients.failed());
        }

            ,
        right: (newPatient) {
          if (newPatient != null) {
            print(newPatient.toJson());
            sessionController.patients = newPatient;
            sessionController.setUser(newPatient.user);
            patients = newPatient;
            sessionController.notifyListeners();
          }
          return state.copyWith(
              associatePatients: AssociatePatientPatients.loaded(newPatient));
        });
  }
}
