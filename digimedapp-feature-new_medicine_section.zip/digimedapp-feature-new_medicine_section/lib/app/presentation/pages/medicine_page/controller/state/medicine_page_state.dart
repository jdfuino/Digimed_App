import 'package:digimed/app/domain/failures/http_request/http_request_failure.dart';
import 'package:digimed/app/domain/models/medicine/medicine.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'medicine_page_state.freezed.dart';

@freezed
class MedicinePageState with _$MedicinePageState {
  const factory MedicinePageState({
    @Default(MedicineState.loading()) MedicineState medicineState,
    @Default(false) bool isFetching,
    @Default(RequestState.normal()) RequestState requestState,
  }) = _MedicinePageState;
}

@freezed
class MedicineState with _$MedicineState {
  const factory MedicineState.loading() = MedicineStateLoading;

  const factory MedicineState.failed(HttpRequestFailure failure) =
      MedicineStateFailed;

  const factory MedicineState.loaded(List<Medicine> medicines) =
      MedicineStateLoaded;
}

@freezed
class RequestState with _$RequestState {
  const factory RequestState.normal() = RequestStateNormal;

  const factory RequestState.loading() = RequestStateLoading;

  const factory RequestState.failed(HttpRequestFailure failure) =
      RequestStateFailed;
}
