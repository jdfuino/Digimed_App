import 'package:digimed/app/presentation/global/state_notifier.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/state/medicine_page_state.dart';

class MedicineController extends StateNotifier<MedicinePageState> {
  List<Medicine> medicines = [];

  MedicineController(super.state);

  void addMedicine(Medicine medicine) {
    medicines.add(medicine);
    notifyListeners();
    print("Medicamento agregado: ${medicine.name}");
  }
}

class Medicine {
  final String name;
  final String concentration;
  final String unit;
  final String description;

  Medicine({
    required this.name,
    required this.concentration,
    required this.unit,
    required this.description,
  });
}
