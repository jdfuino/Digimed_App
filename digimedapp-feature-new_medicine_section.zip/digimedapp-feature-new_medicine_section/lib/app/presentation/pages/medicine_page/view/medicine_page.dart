import 'package:digimed/app/domain/models/patients/patients.dart';
import 'package:digimed/app/generated/assets.gen.dart';
import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/icons/digimed_icon_icons.dart';
import 'package:digimed/app/presentation/global/widgets/banner_digimed.dart';
import 'package:digimed/app/presentation/global/widgets/button_digimed.dart';
import 'package:digimed/app/presentation/global/widgets/card_digimed.dart';
import 'package:digimed/app/presentation/global/widgets/form_new_medicine/view/form_new_medicine.dart';
import 'package:digimed/app/presentation/global/widgets/my_scaffold.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/medicine_controller.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/state/medicine_page_state.dart';
import 'package:digimed/app/presentation/pages/medicine_page/view/widget/desciption_recipe_page.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MedicinePage extends StatelessWidget {
  final int userID;
  final Patients patients;

  const MedicinePage({super.key, required this.userID, required this.patients});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => MedicineController(const MedicinePageState()),
      child: MyScaffold(
        body: Builder(
          builder: (context) {
            final controller = Provider.of<MedicineController>(
              context,
              listen: true,
            );
            return SingleChildScrollView(
              child: Column(
                children: [
                  BannerDigimed(
                    textLeft: "Recipe",
                    iconLeft: DigimedIcon.detail_user,
                    iconRight: DigimedIcon.back,
                    onClickIconRight: () {
                      Navigator.of(context).pop();
                    },
                    firstLine: "Paciente",
                    secondLine: "${patients.user.fullName}",
                    lastLine:
                        "${patients.user.identificationType}. ${patients.user.identificationNumber}",
                    imageProvider: isValidUrl(patients.user.urlImageProfile)
                        ? NetworkImage(patients.user.urlImageProfile!)
                        : Assets.images.logo.provider(),
                  ),
                  Container(
                    margin: const EdgeInsets.only(
                        right: 24, left: 24, bottom: 16, top: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Container(
                                margin:
                                    const EdgeInsets.only(right: 4, left: 10),
                                child: Text(
                                  "Agregar Medicamentos al Paciente",
                                  softWrap: true,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style:
                                      AppTextStyle.normal16W500ContentTextStyle,
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(
                                Icons.add_circle_outline_sharp,
                                color: AppColors.backgroundColor,
                                size: 32,
                              ),
                              onPressed: () async {
                                await showDialog(
                                    context: context,
                                    builder: (context) => FormNewMedicine());
                              },
                            )
                          ],
                        ),
                        Container(
                          margin: const EdgeInsets.only(left: 12, right: 12),
                          child: const Divider(),
                        ),
                        Container(
                          height: 290,
                          margin: const EdgeInsets.only(left: 2, right: 2),
                          width: double.infinity,
                          child: CardDigimed(
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  TextFormField(
                                    keyboardType: TextInputType.text,
                                    style: AppTextStyle.normalTextStyle2,
                                    autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                    onChanged: (text) {},
                                    decoration: InputDecoration(
                                      filled: true,
                                      fillColor:
                                          AppColors.backgroundSearchColor,
                                      hintText: 'Búsqueda detallada',
                                      hintStyle: AppTextStyle.hintTextStyle,
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          20.0, 15.0, 20.0, 15.0),
                                      prefixIcon: const Icon(
                                        DigimedIcon.search,
                                        size: 14,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                        borderSide: const BorderSide(
                                            width: 0.2,
                                            color: AppColors
                                                .backgroundSearchColor),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 16,
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(
                                        right: 8, left: 8),
                                    child: Row(
                                      children: [
                                        Text(
                                          "Medicamentos Asignados",
                                          style: AppTextStyle
                                              .normalContentTextStyle,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    height: 150,
                                    margin: const EdgeInsets.only(
                                        right: 2, left: 2, top: 8),
                                    child: Center(
                                      child: ListView.builder(
                                        itemCount: controller.medicines.length,
                                        itemBuilder: (context, index) {
                                          final medicine =
                                              controller.medicines[index];
                                          return ListTile(
                                            title: Text(medicine.name),
                                            subtitle: Text(
                                                '${medicine.concentration} ${medicine.unit}'),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        ButtonDigimed(
                          child: const Text("Siguiente"),
                          onTab: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => DescriptionRecipePage(
                                        userID: userID,
                                        patients: patients,
                                      )),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
