import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/historic_patients_controller.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class GraphTriglycerides extends StatelessWidget {
  const GraphTriglycerides({super.key});

  @override
  Widget build(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    final Size size = MediaQuery.of(context).size;
    return Container(
      margin: const EdgeInsets.only(right: 20, left: 8, bottom: 16),
      height: 200,
      child: Stack(
        children: [
          BarChart(
            BarChartData(
              barTouchData: BarTouchData(
                touchTooltipData: BarTouchTooltipData(
                  tooltipBgColor: AppColors.backgroundColor,
                  getTooltipItem: (group, groupIndex, rod, rodIndex) {
                    // para mostrar solo 2 digitos despues de la coma.
                    String formattedValue = rod.toY.toStringAsFixed(2);
                    return BarTooltipItem(
                      formattedValue,
                      const TextStyle(color: AppColors.scaffoldBackgroundColor),
                    );
                  },
                ),
              ),
              minY: 0,
              maxY: 500,
              gridData: const FlGridData(
                show: true,
                drawVerticalLine: false,
                drawHorizontalLine: true,
                horizontalInterval: 100,
              ),
              titlesData: FlTitlesData(
                show: true,
                rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (values, meta) {
                      int index = values.toInt();
                      String textX = "";
                      switch (
                          rangeGraph[controller.valueSelectedTriglycerides]) {
                        case "WEEK":
                          textX = getDay(index);
                          break;
                        case "MONTH":
                          textX = getWeek(
                              controller.listXTriglycerides[index].x.toInt());
                          break;
                        case "HALF_YEAR":
                          textX = obtenerAbreviaturaMes(
                              controller.listXTriglycerides[index].x.toInt());
                          break;
                        case "YEAR":
                          textX = obtenerAbreviaturaMes(
                              controller.listXTriglycerides[index].x.toInt());
                          break;
                        default:
                      }

                      return SideTitleWidget(
                        axisSide: meta.axisSide,
                        child: Text(
                          textX,
                          style: TextStyle(color: Colors.black, fontSize: 10),
                        ),
                      );
                    },
                  ),
                ),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    interval: 100,
                    reservedSize: 32,
                    getTitlesWidget: (values, meta) {
                      TextStyle style = AppTextStyle.sub9BoldContentTextStyle;
                      Widget text = Text(
                        values.round().toString(),
                        style: style,
                      );

                      return SideTitleWidget(
                        axisSide: meta.axisSide,
                        child: text,
                      );
                    },
                  ),
                ),
              ),
              borderData: FlBorderData(
                show: false,
              ),
              barGroups: controller.listXTriglycerides.map((yValue) {
                var x = searchPositionInTheList(
                    yValue.x, controller.listXTriglycerides);

                double barWidth =
                    (rangeGraph[controller.valueSelectedTriglycerides] == "YEAR")
                        ? 20.0
                        : 25.0;

                return BarChartGroupData(
                  x: x,
                  barRods: [
                    BarChartRodData(
                      fromY: 0,
                      toY: yValue.y,
                      width: barWidth,
                      color: AppColors.backgroundColor.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(2),
                      borderSide: const BorderSide(
                        color: AppColors.backgroundColor,
                        width: 2.0,
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          Stack(
            children: [
              Container(
                width: double.infinity,
                height: 3,
                margin: EdgeInsets.only(top: 123, left: 31),
                color: Colors.green,
              ),
            ],
          ),
        ],
      ),
    );
  }
}


 // return Container(
    //   margin: const EdgeInsets.only(right: 20, left: 8,bottom: 16),
    //   height: 200,
    //   child: LineChart(LineChartData(
    //     gridData: FlGridData(
    //       show: true,
    //       drawVerticalLine: false,
    //         drawHorizontalLine: true,
    //         horizontalInterval: 100
    //     ),
    //     lineTouchData: LineTouchData(
    //         touchTooltipData: LineTouchTooltipData(
    //             tooltipBgColor: AppColors.backgroundColor,
    //             getTooltipItems: (touch){
    //               return touch.map((LineBarSpot touchedSpot){
    //                 final textStyle = TextStyle(
    //                   color: Colors.white,
    //                   fontWeight: FontWeight.bold,
    //                 );
    //                 var x = searchPositionInTheList(touchedSpot.x, controller.listXTriglycerides);
    //                 return LineTooltipItem("${touchedSpot.y.toString()} \n ${formatDate(controller.listDateTriglycerides[x])}", textStyle);
    //               }).toList();
    //             }
    //         )),
    //     titlesData: FlTitlesData(
    //       show: true,
    //       rightTitles: const AxisTitles(
    //         sideTitles: SideTitles(showTitles: false),
    //       ),
    //       topTitles: const AxisTitles(
    //         sideTitles: SideTitles(showTitles: false),
    //       ),
    //       bottomTitles: const AxisTitles(
    //         sideTitles: SideTitles(showTitles: false),
    //       ),
    //       leftTitles: AxisTitles(
    //         sideTitles: SideTitles(
    //           showTitles: true,
    //           interval: 100,
    //           reservedSize: 32,
    //             getTitlesWidget: (values,meta){
    //               TextStyle style =
    //                   AppTextStyle.sub9BoldContentTextStyle;
    //               Widget text;
    //               text = Text(
    //                   values.round().toString(),
    //                   style: style);
    //               return SideTitleWidget(
    //                 axisSide: meta.axisSide,
    //                 child: text,
    //               );
    //             }
    //         ),
    //       ),
    //     ),
    //     borderData: FlBorderData(
    //       show: false,
    //     ),
    //     minX: 0,
    //     maxX: 1,
    //     minY: 0,
    //     maxY: 500,
    //     lineBarsData: [
    //       LineChartBarData(
    //         spots: controller.listXTriglycerides,
    //         isCurved: true,
    //         color: AppColors.backgroundColor,
    //         barWidth: 2,
    //         isStrokeCapRound: true,
    //         dotData: const FlDotData(
    //           show: false,
    //         ),
    //         belowBarData: BarAreaData(
    //           show: true,
    //           gradient: LinearGradient(
    //             colors: AppColors.gradientColors
    //                 .map((color) => color.withOpacity(0.3))
    //                 .toList(),
    //             begin: Alignment.topCenter,
    //             end: Alignment.bottomCenter,
    //           ),
    //         ),
    //       ),
    //     ],
    //   )),
    // );