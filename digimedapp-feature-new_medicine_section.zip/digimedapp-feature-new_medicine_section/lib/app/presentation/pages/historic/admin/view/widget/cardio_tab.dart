import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/widgets/card_digimed.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/historic_patients_controller.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_diastolic.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_systolic.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_uric_acid.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TabCardio extends StatelessWidget {
  const TabCardio({super.key});

  @override
  Widget build(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    final Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(right: 24, left: 24, top: 16, bottom: 16),
        child: Column(
          children: [
            Text(
              controller.state.bloodPressureDataState.when(
                  loading: () => "Presión arterial promedio: 0/0 mmHg",
                  failed: (failed) => "Presión arterial promedio: 0/0 mmHg",
                  loaded: (_) {
                    return "Presión arterial promedio: ${showNumber(controller.promSistolica)}/${showNumber(controller.promDiastolic)} mmHg";
                  },
                  nullData: () => ""),
              style: AppTextStyle.normal15W500ContentTextStyle,
            ),
            SizedBox(
              height: 16,
            ),
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Presión sistólica",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      Spacer(),
                      controller.state.bloodPressureDataState.when(loading: () {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }, failed: (failed) {
                        return _dropMenu(context);
                      }, loaded: (_) {
                        return _dropMenu(context);
                      }, nullData: () {
                        return _dropMenu(context);
                      })
                    ],
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                controller.state.bloodPressureDataState.when(loading: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }, failed: (_) {
                  return Container(
                    child: errorMessage(),
                  );
                }, nullData: () {
                  return Container(
                    child: errorMessage(),
                  );
                }, loaded: (list) {
                  if (list != null && list.isNotEmpty) {
                    return const GraphSystolic();
                  } else {
                    return errorMessage();
                  }
                })
              ],
            )),
            SizedBox(
              height: 16,
            ),
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Presión diastólica",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      Spacer(),
                    ],
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                controller.state.bloodPressureDataState.when(loading: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }, failed: (_) {
                  return Container(
                    child: errorMessage(),
                  );
                }, nullData: () {
                  return Container(
                    child: errorMessage(),
                  );
                }, loaded: (list) {
                  if (list != null && list.isNotEmpty) {
                    return const GraphDiastolic();
                  } else {
                    return errorMessage();
                  }
                })
              ],
            )),
            SizedBox(
              height: 32,
            )
          ],
        ),
      ),
    );
  }

  Widget _dropMenu(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          child: Row(
            children: <Widget>[
              Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedSystolic,
                  style: AppTextStyle.normalBlueTextStyle),
              SizedBox(
                width: 8,
              )
            ],
          ),
          color: AppColors.buttonSelectedRangeColor,
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedSystolic = value;
        controller.getDataBloodPressure(
            bloodPressureDataState: const BloodPressureDataState.loading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: ListTile(
              title: Text(value),
              leading: Radio<String>(
                value: value,
                groupValue: controller.valueSelectedSystolic,
                onChanged: (value) {
                  if (value != null) {
                    controller.valueSelectedSystolic = value;
                    controller.getDataBloodPressure(
                        bloodPressureDataState:
                            const BloodPressureDataState.loading());
                    Navigator.pop(context);
                  }
                },
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
