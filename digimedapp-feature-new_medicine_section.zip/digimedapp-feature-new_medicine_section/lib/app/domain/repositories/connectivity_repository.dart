
 abstract class ConnectivityRepository{
  Future<bool> get hasInternet;
}