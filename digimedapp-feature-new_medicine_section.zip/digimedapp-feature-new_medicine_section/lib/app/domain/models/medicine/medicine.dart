import 'package:freezed_annotation/freezed_annotation.dart';

part 'medicine.freezed.dart';
part 'medicine.g.dart';

@freezed
class Medicine with _$Medicine {
  const factory Medicine({
    @JsonKey(name: 'name') required String name,
    @JsonKey(name: 'concentration') required String concentration,
    @JsonKey(name: 'unit') required String unit,
    @JsonKey(name: 'description') String? description, // Opcional
  }) = _Medicine;

  const Medicine._();

  factory Medicine.fromJson(Map<String, dynamic> json) =>
      _$MedicineFromJson(json);
}