import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:digimed/app/data/http/grapgh_ql_digimed.dart';
import 'package:digimed/app/data/http/http.dart';
import 'package:digimed/app/data/providers/firebase/firebase_api.dart';
import 'package:digimed/app/domain/globals/session_service.dart';
import 'package:digimed/app/inject_repositories.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/medicine_controller.dart';
import 'package:digimed/app/presentation/pages/medicine_page/controller/state/medicine_page_state.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:http/http.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:digimed/app/data/providers/remote/internet_checker.dart';
import 'package:digimed/app/my_app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // config acc to platform
  final FirebaseOptions firebaseOptions = (Platform.isIOS || Platform.isMacOS)
      ? const FirebaseOptions(
          apiKey: 'AIzaSyBWzLnP5r0bbyk9Yj2Ca1k0TokU89mdDqE',
          appId: '1:130351280458:ios:4c5d9b3ad8db8cd30351b3',
          messagingSenderId: '130351280458',
          projectId: 'digimed-ae1d4',
          storageBucket: 'digimed-ae1d4.appspot.com',
        )
      : const FirebaseOptions(
          apiKey: 'AIzaSyDAtlBo5nY5e-TxLH0-K9V5ii5SZCpMARw',
          appId: '1:130351280458:android:7d86a3357e1773970351b3',
          messagingSenderId: '130351280458',
          projectId: 'digimed-ae1d4',
          storageBucket: 'digimed-ae1d4.appspot.com',
        );

  await Firebase.initializeApp(options: firebaseOptions);
  await FirebaseApi().initNotifications();

  final http = Http(
    client: Client(),
    baseUrl: 'https://api.themoviedb.org/3',
    apiKey: '4248991ee7e5702debde74e854effa57',
  );

  final HttpLink httpLink = HttpLink(
    //'http://172.16.0.171:4000/query'
    //'http://172.16.0.153:4000/query'
    // 'https://digimed.priver.app/query',
    'https://devdigimed.priver.app/query',
  );

  final GraphQLClient client = GraphQLClient(
    cache: GraphQLCache(),
    link: httpLink,
  );

  final GraphQLDigimed graphQLDigimed = GraphQLDigimed(
    client: client,
    link:
        //'http://172.16.0.171:4000/query'
        //'http://172.16.0.153:4000/query'
        // 'https://digimed.priver.app/query',
        'https://devdigimed.priver.app/query',
  );

  final NavigationService navigationService = NavigationService();
  await injectRepositories(
      connectivity: Connectivity(),
      http: http,
      secureStorage: const FlutterSecureStorage(),
      internetChecker: InternetChecker(),
      imagePicker: ImagePicker(),
      imageCropper: ImageCropper(),
      navigationService: navigationService,
      graphQLDigimed: graphQLDigimed);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<SessionController>(
            create: (_) => SessionController(
                authenticationRepository: Repositories.authentication)),
      ],
      child: const MyApp(),
    ),
  );
}
