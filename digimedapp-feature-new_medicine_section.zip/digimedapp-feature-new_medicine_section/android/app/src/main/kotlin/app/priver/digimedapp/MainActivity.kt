package app.priver.digimedapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
