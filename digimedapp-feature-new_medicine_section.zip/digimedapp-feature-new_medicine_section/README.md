# local deploy

Run
```bash
flutter pub get
```
```bash
dart run build_runner build 
```
```bash
flutter build appbundle
```