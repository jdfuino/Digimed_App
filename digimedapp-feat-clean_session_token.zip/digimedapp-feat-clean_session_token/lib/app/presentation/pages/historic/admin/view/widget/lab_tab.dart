import 'package:digimed/app/domain/constants/value_range.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/historic_patients_controller.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_cholesterol.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_glucose.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_hemoglobin.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_triglycerides.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LabTab extends StatelessWidget {
  const LabTab({super.key});

  @override
  Widget build(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    final Size size = MediaQuery
        .of(context)
        .size;
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(right: 24, left: 24, top: 16, bottom: 16),
        child: Column(
          children: [
            GraphGlucose(
              title: "Glucemia",
              valueProm: controller.promGlucose,
              maxSafeZone: ValueRange.glucoseMax,
              minSafeZone: ValueRange.glucoseMin,
              unit: "mg/dl",
              maxValue: 300,
              dataBarGroups: controller.listBarDataGlucose,
              buildStatusMessage: () {
                return controller.state.glucoseDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) =>
                        Text(
                          getGlucoseMessage(
                              controller.promGlucose),
                          style: AppTextStyle.grey13W500ContentTextStyle,
                        ));
              },
              onTimeSelected: (value) {
                controller.valueSelectedGlucose = value;
                controller.getDataGlucose(
                    glucoseDataState:
                    const GlucoseDataState.loading());
              },
            ),
            const SizedBox(
              height: 16,
            ),
            GraphTriglycerides(
              title: "Triglicéridos",
              valueProm: controller.promTriglycerides,
              maxSafeZone: ValueRange.triglyceridesMax,
              unit: "mg/dl",
              maxValue: 500,
              dataBarGroups: controller.listBarDataTriglycerides,
              buildStatusMessage: () {
                return controller.state.triglyceridesDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) =>
                        Text(
                          getTriglyceridesMessage(controller.promTriglycerides),
                          style: AppTextStyle.grey13W500ContentTextStyle,
                        ));
              },
              onTimeSelected: (value) {
                controller.valueSelectedTriglycerides = value;
                controller.getDataTriglycerides(
                    triglyceridesDataState:
                    const TriglyceridesDataState.loading());
              },
            ),
            const SizedBox(
              height: 16,
            ),
            GraphCholesterol(
              title: "Colesterol No-HDL",
              valueProm: controller.promCholesterol,
              maxSafeZone: ValueRange.cholesterolMax,
              unit: "mg/dl",
              maxValue: 300,
              dataBarGroups: controller.listBarDataCholesterol,
              buildStatusMessage: () {
                return controller.state.cholesterolDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) =>
                        Text(
                          getCholesterolMessage(controller.promCholesterol),
                          style: AppTextStyle.grey13W500ContentTextStyle,
                        ));
              },
              onTimeSelected: (value) {
                controller.valueSelectedCholesterol = value;
                controller.getDataCholesterol(
                    cholesterolDataState:
                    const CholesterolDataState.loading());
              },
            ),
            const SizedBox(
              height: 16,
            ),
            GraphHemoglobin(
              title: "Hemoglobina (g/dL)",
              valueProm: controller.promHemoglobin,
              maxSafeZone: ValueRange.hemoglobinMaleMax,
              minSafeZone: ValueRange.hemoglobinMaleMin,
              unit: "g/dL",
              maxValue: 30,
              dataBarGroups: controller.listBarDataHemoglobin,
              buildStatusMessage: () {
                return controller.state.hemoglobinDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) =>
                        Text(
                          getHemoglobinMessage(
                              controller.promHemoglobin, "Male"),
                          style: AppTextStyle.grey13W500ContentTextStyle,
                        ));
              },
              onTimeSelected: (value) {
                controller.valueSelectedHemoglobin = value;
                controller.getDataHemoglobin(
                    hemoglobinDataState:
                    const HemoglobinDataState.loading());
              },
            ),
            const SizedBox(
              height: 32,
            ),
          ],
        ),
      ),
    );
  }
}
