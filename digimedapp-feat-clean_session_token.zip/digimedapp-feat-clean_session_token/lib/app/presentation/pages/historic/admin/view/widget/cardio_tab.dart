import 'package:digimed/app/domain/constants/value_range.dart';
import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/widgets/card_digimed.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/historic_patients_controller.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_diastolic.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/chart_card.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_systolic.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_uric_acid.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TabCardio extends StatelessWidget {
  const TabCardio({super.key});

  @override
  Widget build(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    final Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(right: 24, left: 24, top: 16, bottom: 16),
        child: Column(
          children: [
            Text(
              controller.state.bloodPressureDataState.when(
                  loading: () => "Presión arterial promedio: 0/0 mmHg",
                  failed: (failed) => "Presión arterial promedio: 0/0 mmHg",
                  loaded: (_) {
                    return "Presión arterial promedio: ${showNumber(controller.promSistolica)}/${showNumber(controller.promDiastolic)} mmHg";
                  },
                  nullData: () => ""),
              style: AppTextStyle.normal15W500ContentTextStyle,
            ),
            const SizedBox(height: 16),

            // Nueva tarjeta mejorada para presión sistólica
            ChartCard(
              title: "Presión Sistólica",
              valueProm: controller.promSistolica,
              maxSafeZone: ValueRange.systolicMax,
              minSafeZone: ValueRange.systolicMin,
              maxValue: 200,
              unit: "mmHg",
              dataBarGroups: controller.listBarDataSystolic,
              buildStatusMessage: () {
                return controller.state.bloodPressureDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) => Text(
                          getSystolicPressureMessage(controller.promSistolica),
                          style: AppTextStyle.grey13W500ContentTextStyle,
                        ));
              },
              onTimeSelected: (String value) {
                controller.valueSelectedSystolic = value;
                controller.getDataBloodPressure(
                    bloodPressureDataState:
                        const BloodPressureDataState.loading());
              },
            ),

            const SizedBox(height: 16),

            ChartCard(
              title: "Presión Diastólica",
              valueProm: controller.promDiastolic,
              maxSafeZone: ValueRange.diastolicMax,
              minSafeZone: ValueRange.diastolicMin,
              unit: "mmHg",
              maxValue: 150,
              showSelectedTime: false,
              dataBarGroups: controller.listBarDataDiastolic,
              buildStatusMessage: () {
                return controller.state.bloodPressureDataState.when(
                    loading: () => const SizedBox.shrink(),
                    failed: (failed) => const SizedBox.shrink(),
                    nullData: () => const SizedBox.shrink(),
                    loaded: (_) => Text(
                      getDiastolicPressureMessage(controller.promDiastolic),
                      style: AppTextStyle.grey13W500ContentTextStyle,
                    ));
              },
              onTimeSelected: (_) {},
            ),
            const SizedBox(
              height: 32,
            )
          ],
        ),
      ),
    );
  }
}
