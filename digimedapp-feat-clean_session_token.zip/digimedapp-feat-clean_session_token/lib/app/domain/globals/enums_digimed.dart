const Map<int, String> dayDigimed = {
  0: "Domingo",
  1: "Lunes",
  2: "Martes",
  3: "Miércoles",
  4: "Jueves",
  5: "Viernes",
  6: "Sábado"
};

const Map<int,String>followUpMethod={
  0:"REGULAR_MEDICAL_CONSULTATION",
  1:"TELEMEDICINE",
  2:"PRIMARY_HEALTH_CARE",
  3:"INSURED",
  4:"NO_MEDICAL_CONTROL",
};