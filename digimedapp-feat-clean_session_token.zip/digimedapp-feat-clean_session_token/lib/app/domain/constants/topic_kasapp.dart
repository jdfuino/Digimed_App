import 'package:flutter/material.dart';

class TopicDigimed {
  static const String appName = "digimed";
  static const String allUsers = "all";
  static const String topicPatient = "patient";
  static const String topicDoctor = "doctor";
  static const String topicProperty = "property_";
}