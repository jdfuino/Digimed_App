import 'package:digimed/app/domain/models/data_graph/data_graph.dart';
import 'package:digimed/app/domain/models/profile_cardiovascular/profile_cardiovascular.dart';
import 'package:digimed/app/domain/models/profile_laboratory/profile_laboratory.dart';
import 'package:digimed/app/domain/models/uric_acid_fake/uric_acid_fake.dart';
import 'package:digimed/app/domain/repositories/accountRepository.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/global/state_notifier.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:fl_chart/fl_chart.dart';

class HistoricPatientsController extends StateNotifier<HistoricPatientsState> {
  final AccountRepository accountRepository;
  final SessionController sessionController;
  final int patientId;

  HistoricPatientsController(super._state,
      {required this.accountRepository,
      required this.sessionController,
      required this.patientId});

  List listOption = ["1 semana", "1 mes", "6 meses", "1 año"];

  //Data Systolic
  String valueSelectedSystolic = "6 meses";
  List<FlSpot> listXSistolica = [];

  //double scaleNew = 1;
  double promSistolica = 0;

  //Data Diastolic
  List<FlSpot> listXDiastolic = [];
  double promDiastolic = 0;

  //Data Heart Rate
  String valueSelectedRate = "6 meses";
  List<FlSpot> listXRate = [];
  double promRate = 0;

  //Data Glucose
  String valueSelectedGlucose = "6 meses";
  List<FlSpot> listXGlucose = [];

  //Data Triglycerides
  String valueSelectedTriglycerides = "6 meses";
  List<FlSpot> listXTriglycerides = [];

  //Data Cholesterol
  String valueSelectedCholesterol = "6 meses";
  List<FlSpot> listXCholesterol = [];

  //Data Hemoglobin
  String valueSelectedHemoglobin = "6 meses";
  List<FlSpot> listXHemoglobin = [];

  //Data UricAcid
  String valueSelectedUricAcid = "6 meses";
  List<FlSpot> listXUricAcid = [];
  double promUricAcid = 0;

  Future<void> init() async {
    await getDataBloodPressure();
    await getDataHeartFrequency();
    await getDataGlucose();
    await getDataTriglycerides();
    await getDataCholesterol();
    await getDataHemoglobin();
    await getDataUricAcid();
  }

  Future<void> getDataBloodPressure(
      {BloodPressureDataState? bloodPressureDataState}) async {
    if (bloodPressureDataState != null) {
      state = state.copyWith(bloodPressureDataState: bloodPressureDataState);
    }

    final result = await accountRepository.getDataBloodPressure(
        patientId, rangeGraph[valueSelectedSystolic]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          bloodPressureDataState: BloodPressureDataState.failed(failed));
    }, right: (list) {
      print(list);
      if (list != null) {
        getParamsGraphSystolic(list);
        return state.copyWith(
            bloodPressureDataState: BloodPressureDataState.loaded(list));
      }
      return state.copyWith(
          bloodPressureDataState: const BloodPressureDataState.nullData());
    });
  }

  Future<void> getDataHeartFrequency(
      {HeartFrequencyDataState? heartFrequencyDataState}) async {
    if (heartFrequencyDataState != null) {
      state = state.copyWith(heartFrequencyDataState: heartFrequencyDataState);
    }

    final result = await accountRepository.getDataHeartFrequency(
        patientId, rangeGraph[valueSelectedRate]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          heartFrequencyDataState: HeartFrequencyDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphHearRate(list);
        return state.copyWith(
            heartFrequencyDataState: HeartFrequencyDataState.loaded(list));
      }
      return state.copyWith(
          heartFrequencyDataState: const HeartFrequencyDataState.nullData());
    });
  }

  Future<void> getDataGlucose({GlucoseDataState? glucoseDataState}) async {
    if (glucoseDataState != null) {
      state = state.copyWith(glucoseDataState: glucoseDataState);
    }
    final result = await accountRepository.getDataGlucose(
        patientId, rangeGraph[valueSelectedGlucose]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(glucoseDataState: GlucoseDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphGlucose(list);
        return state.copyWith(glucoseDataState: GlucoseDataState.loaded(list));
      }
      return state.copyWith(
          glucoseDataState: const GlucoseDataState.nullData());
    });
  }

  Future<void> getDataTriglycerides(
      {TriglyceridesDataState? triglyceridesDataState}) async {
    if (triglyceridesDataState != null) {
      state = state.copyWith(triglyceridesDataState: triglyceridesDataState);
    }

    final result = await accountRepository.getDataTriglycerides(
        patientId, rangeGraph[valueSelectedTriglycerides]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          triglyceridesDataState: TriglyceridesDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphTriglycerides(list);
        return state.copyWith(
            triglyceridesDataState: TriglyceridesDataState.loaded(list));
      }
      return state.copyWith(
          triglyceridesDataState: const TriglyceridesDataState.nullData());
    });
  }

  Future<void> getDataCholesterol(
      {CholesterolDataState? cholesterolDataState}) async {
    if (cholesterolDataState != null) {
      state = state.copyWith(cholesterolDataState: cholesterolDataState);
    }

    final result = await accountRepository.getDataCholesterol(
        patientId, rangeGraph[valueSelectedCholesterol]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          cholesterolDataState: CholesterolDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphCholesterol(list);
        return state.copyWith(
            cholesterolDataState: CholesterolDataState.loaded(list));
      }
      return state.copyWith(
          cholesterolDataState: const CholesterolDataState.nullData());
    });
  }

  Future<void> getDataHemoglobin(
      {HemoglobinDataState? hemoglobinDataState}) async {
    if (hemoglobinDataState != null) {
      state = state.copyWith(hemoglobinDataState: hemoglobinDataState);
    }

    final result = await accountRepository.getDataHemoglobin(
        patientId, rangeGraph[valueSelectedHemoglobin]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          hemoglobinDataState: HemoglobinDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphHemoglobin(list);
        return state.copyWith(
            hemoglobinDataState: HemoglobinDataState.loaded(list));
      }
      return state.copyWith(
          hemoglobinDataState: const HemoglobinDataState.nullData());
    });
  }

  Future<void> getDataUricAcid({UricAcidDataState? uricAcidDataState}) async {
    if (uricAcidDataState != null) {
      state = state.copyWith(uricAcidDataState: uricAcidDataState);
    }

    final result = await accountRepository.getDataUricAcid(
        patientId, rangeGraph[valueSelectedUricAcid]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          uricAcidDataState: UricAcidDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphUricAcid(list);
        if (listXUricAcid.isEmpty) {
          return state.copyWith(
              uricAcidDataState: const UricAcidDataState.nullData());
        }
        return state.copyWith(
            uricAcidDataState: UricAcidDataState.loaded(list));
      }
      return state.copyWith(
          uricAcidDataState: const UricAcidDataState.nullData());
    });
  }

  //Systolic Data
  void getParamsGraphSystolic(List<ProfileCardiovascular> list) {
    listXSistolica = [];
    listXDiastolic = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortSistolica = {};
      Map<int, DataGraph> mapSortDiastolic = {};
      double totalAverageSistolic = 0;
      double totalAverageDiastolic = 0;

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        totalAverageSistolic += element.systolicPressure!;
        totalAverageDiastolic += element.diastolicPressure!;

        if (!mapSortSistolica.containsKey(month)) {
          mapSortSistolica[month] =
              DataGraph(count: 1, sum: element.systolicPressure ?? 0);
        } else {
          int newCount = mapSortSistolica[month]!.count + 1;
          double newSum =
              mapSortSistolica[month]!.sum + (element.systolicPressure ?? 0);
          mapSortSistolica[month] = DataGraph(count: newCount, sum: newSum);
        }

        if (!mapSortDiastolic.containsKey(month)) {
          mapSortDiastolic[month] =
              DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
        } else {
          int newCount = mapSortDiastolic[month]!.count + 1;
          double newSum =
              mapSortDiastolic[month]!.sum + (element.diastolicPressure ?? 0);
          mapSortDiastolic[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortSistolica.forEach((key, value) {
        double promSystolica = value.sum / value.count;
        listXSistolica.add(FlSpot(key.toDouble(), promSystolica));
      });
      promSistolica = totalAverageSistolic / list.length;

      mapSortDiastolic.forEach((key, value) {
        double promDiastolic = value.sum / value.count;
        listXDiastolic.add(FlSpot(key.toDouble(), promDiastolic));
      });
      promDiastolic = totalAverageDiastolic / list.length;
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortSistolica = {};
      Map<int, DataGraph> mapSortDiastolic = {};
      double totalAverageSistolic = 0;
      double totalAverageDiastolic = 0;
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        totalAverageSistolic += element.systolicPressure!;
        totalAverageDiastolic += element.diastolicPressure!;

        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortSistolica.containsKey(0)) {
            mapSortSistolica[0] =
                DataGraph(count: 1, sum: element.systolicPressure ?? 0);
          } else {
            int newCount = mapSortSistolica[0]!.count + 1;
            double newSum =
                mapSortSistolica[0]!.sum + (element.systolicPressure ?? 0);
            mapSortSistolica[0] = DataGraph(count: newCount, sum: newSum);
          }

          if (!mapSortDiastolic.containsKey(0)) {
            mapSortDiastolic[0] =
                DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
          } else {
            int newCount = mapSortDiastolic[0]!.count + 1;
            double newSum =
                mapSortDiastolic[0]!.sum + (element.diastolicPressure ?? 0);
            mapSortDiastolic[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortSistolica.containsKey(1)) {
            mapSortSistolica[1] =
                DataGraph(count: 1, sum: element.systolicPressure ?? 0);
          } else {
            int newCount = mapSortSistolica[1]!.count + 1;
            double newSum =
                mapSortSistolica[1]!.sum + (element.systolicPressure ?? 0);
            mapSortSistolica[1] = DataGraph(count: newCount, sum: newSum);
          }

          if (!mapSortDiastolic.containsKey(1)) {
            mapSortDiastolic[1] =
                DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
          } else {
            int newCount = mapSortDiastolic[1]!.count + 1;
            double newSum =
                mapSortDiastolic[1]!.sum + (element.diastolicPressure ?? 0);
            mapSortDiastolic[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortSistolica.containsKey(2)) {
            mapSortSistolica[2] =
                DataGraph(count: 1, sum: element.systolicPressure ?? 0);
          } else {
            int newCount = mapSortSistolica[2]!.count + 1;
            double newSum =
                mapSortSistolica[2]!.sum + (element.systolicPressure ?? 0);
            mapSortSistolica[2] = DataGraph(count: newCount, sum: newSum);
          }

          if (!mapSortDiastolic.containsKey(2)) {
            mapSortDiastolic[2] =
                DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
          } else {
            int newCount = mapSortDiastolic[2]!.count + 1;
            double newSum =
                mapSortDiastolic[2]!.sum + (element.diastolicPressure ?? 0);
            mapSortDiastolic[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortSistolica.containsKey(3)) {
            mapSortSistolica[3] =
                DataGraph(count: 1, sum: element.systolicPressure ?? 0);
          } else {
            int newCount = mapSortSistolica[3]!.count + 1;
            double newSum =
                mapSortSistolica[3]!.sum + (element.systolicPressure ?? 0);
            mapSortSistolica[3] = DataGraph(count: newCount, sum: newSum);
          }

          if (!mapSortDiastolic.containsKey(3)) {
            mapSortDiastolic[3] =
                DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
          } else {
            int newCount = mapSortDiastolic[3]!.count + 1;
            double newSum =
                mapSortDiastolic[3]!.sum + (element.diastolicPressure ?? 0);
            mapSortDiastolic[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortSistolica.forEach((key, value) {
        double promSystolica = value.sum / value.count;
        listXSistolica.add(FlSpot(key.toDouble(), promSystolica));
      });
      promSistolica = totalAverageSistolic / list.length;

      mapSortDiastolic.forEach((key, value) {
        double promDiastolic = value.sum / value.count;
        listXDiastolic.add(FlSpot(key.toDouble(), promDiastolic));
      });
      promDiastolic = totalAverageDiastolic / list.length;
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortSistolica = {};
      Map<int, DataGraph> mapSortDiastolic = {};
      double totalAverageSistolic = 0;
      double totalAverageDiastolic = 0;

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        totalAverageSistolic += element.systolicPressure!;
        totalAverageDiastolic += element.diastolicPressure!;

        if (!mapSortSistolica.containsKey(day)) {
          mapSortSistolica[day] =
              DataGraph(count: 1, sum: element.systolicPressure ?? 0);
        } else {
          int newCount = mapSortSistolica[day]!.count + 1;
          double newSum =
              mapSortSistolica[day]!.sum + (element.systolicPressure ?? 0);
          mapSortSistolica[day] = DataGraph(count: newCount, sum: newSum);
        }

        if (!mapSortDiastolic.containsKey(day)) {
          mapSortDiastolic[day] =
              DataGraph(count: 1, sum: element.diastolicPressure ?? 0);
        } else {
          int newCount = mapSortDiastolic[day]!.count + 1;
          double newSum =
              mapSortDiastolic[day]!.sum + (element.diastolicPressure ?? 0);
          mapSortDiastolic[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortSistolica.forEach((key, value) {
        double promSystolica = value.sum / value.count;
        listXSistolica.add(FlSpot(key.toDouble(), promSystolica));
      });
      promSistolica = totalAverageSistolic / list.length;

      mapSortDiastolic.forEach((key, value) {
        double promDiastolic = value.sum / value.count;
        listXDiastolic.add(FlSpot(key.toDouble(), promDiastolic));
      });
      promDiastolic = totalAverageDiastolic / list.length;
    }

    switch (rangeGraph[valueSelectedSystolic]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //Rate Data
  void getParamsGraphHearRate(List<ProfileCardiovascular> list) {
    listXRate = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortRate = {};
      double totalAverageHearRate = 0;

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        totalAverageHearRate += element.heartFrequency!;

        if (!mapSortRate.containsKey(month)) {
          mapSortRate[month] =
              DataGraph(count: 1, sum: element.heartFrequency ?? 0);
        } else {
          int newCount = mapSortRate[month]!.count + 1;
          double newSum =
              mapSortRate[month]!.sum + (element.heartFrequency ?? 0);
          mapSortRate[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortRate.forEach((key, value) {
        double promRate = value.sum / value.count;
        listXRate.add(FlSpot(key.toDouble(), promRate));
      });
      promRate = totalAverageHearRate / list.length;
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortRate = {};
      double totalAverageHearRate = 0;
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        totalAverageHearRate += element.heartFrequency!;

        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortRate.containsKey(0)) {
            mapSortRate[0] =
                DataGraph(count: 1, sum: element.heartFrequency ?? 0);
          } else {
            int newCount = mapSortRate[0]!.count + 1;
            double newSum = mapSortRate[0]!.sum + (element.heartFrequency ?? 0);
            mapSortRate[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortRate.containsKey(1)) {
            mapSortRate[1] =
                DataGraph(count: 1, sum: element.heartFrequency ?? 0);
          } else {
            int newCount = mapSortRate[1]!.count + 1;
            double newSum = mapSortRate[1]!.sum + (element.heartFrequency ?? 0);
            mapSortRate[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortRate.containsKey(2)) {
            mapSortRate[2] =
                DataGraph(count: 1, sum: element.heartFrequency ?? 0);
          } else {
            int newCount = mapSortRate[2]!.count + 1;
            double newSum = mapSortRate[2]!.sum + (element.heartFrequency ?? 0);
            mapSortRate[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortRate.containsKey(3)) {
            mapSortRate[3] =
                DataGraph(count: 1, sum: element.heartFrequency ?? 0);
          } else {
            int newCount = mapSortRate[3]!.count + 1;
            double newSum = mapSortRate[3]!.sum + (element.heartFrequency ?? 0);
            mapSortRate[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortRate.forEach((key, value) {
        double promRate = value.sum / value.count;
        listXRate.add(FlSpot(key.toDouble(), promRate));
      });
      promRate = totalAverageHearRate / list.length;
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortRate = {};
      double totalAverageHearRate = 0;

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        totalAverageHearRate += element.heartFrequency!;

        if (!mapSortRate.containsKey(day)) {
          mapSortRate[day] =
              DataGraph(count: 1, sum: element.heartFrequency ?? 0);
        } else {
          int newCount = mapSortRate[day]!.count + 1;
          double newSum = mapSortRate[day]!.sum + (element.heartFrequency ?? 0);
          mapSortRate[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortRate.forEach((key, value) {
        double promRate = value.sum / value.count;
        listXRate.add(FlSpot(key.toDouble(), promRate));
      });
      promRate = totalAverageHearRate / list.length;
    }

    switch (rangeGraph[valueSelectedRate]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //Rate Glucose
  void getParamsGraphGlucose(List<ProfileLaboratory> list) {
    listXGlucose = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortGlucose = {};

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        if (!mapSortGlucose.containsKey(month)) {
          mapSortGlucose[month] = DataGraph(count: 1, sum: element.glucose);
        } else {
          int newCount = mapSortGlucose[month]!.count + 1;
          double newSum = mapSortGlucose[month]!.sum + (element.glucose);
          mapSortGlucose[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortGlucose.forEach((key, value) {
        double promGlucose = value.sum / value.count;
        listXGlucose.add(FlSpot(key.toDouble(), promGlucose));
      });
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortGlucose = {};
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortGlucose.containsKey(0)) {
            mapSortGlucose[0] = DataGraph(count: 1, sum: element.glucose);
          } else {
            int newCount = mapSortGlucose[0]!.count + 1;
            double newSum = mapSortGlucose[0]!.sum + (element.glucose);
            mapSortGlucose[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortGlucose.containsKey(1)) {
            mapSortGlucose[1] = DataGraph(count: 1, sum: element.glucose);
          } else {
            int newCount = mapSortGlucose[1]!.count + 1;
            double newSum = mapSortGlucose[1]!.sum + (element.glucose);
            mapSortGlucose[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortGlucose.containsKey(2)) {
            mapSortGlucose[2] = DataGraph(count: 1, sum: element.glucose);
          } else {
            int newCount = mapSortGlucose[2]!.count + 1;
            double newSum = mapSortGlucose[2]!.sum + (element.glucose);
            mapSortGlucose[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortGlucose.containsKey(3)) {
            mapSortGlucose[3] = DataGraph(count: 1, sum: element.glucose);
          } else {
            int newCount = mapSortGlucose[3]!.count + 1;
            double newSum = mapSortGlucose[3]!.sum + (element.glucose);
            mapSortGlucose[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortGlucose.forEach((key, value) {
        double promGlucose = value.sum / value.count;
        listXGlucose.add(FlSpot(key.toDouble(), promGlucose));
      });
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortGlucose = {};

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        if (!mapSortGlucose.containsKey(day)) {
          mapSortGlucose[day] = DataGraph(count: 1, sum: element.glucose);
        } else {
          int newCount = mapSortGlucose[day]!.count + 1;
          double newSum = mapSortGlucose[day]!.sum + (element.glucose);
          mapSortGlucose[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortGlucose.forEach((key, value) {
        double promGlucose = value.sum / value.count;
        listXGlucose.add(FlSpot(key.toDouble(), promGlucose));
      });
    }

    switch (rangeGraph[valueSelectedGlucose]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //Triglycerides Data
  void getParamsGraphTriglycerides(List<ProfileLaboratory> list) {
    listXTriglycerides = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortTriglycerides = {};

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        if (!mapSortTriglycerides.containsKey(month)) {
          mapSortTriglycerides[month] =
              DataGraph(count: 1, sum: element.triglycerides);
        } else {
          int newCount = mapSortTriglycerides[month]!.count + 1;
          double newSum =
              mapSortTriglycerides[month]!.sum + (element.triglycerides);
          mapSortTriglycerides[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortTriglycerides.forEach((key, value) {
        double promTriglycerides = value.sum / value.count;
        listXTriglycerides.add(FlSpot(key.toDouble(), promTriglycerides));
      });
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortTriglycerides = {};
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortTriglycerides.containsKey(0)) {
            mapSortTriglycerides[0] =
                DataGraph(count: 1, sum: element.triglycerides);
          } else {
            int newCount = mapSortTriglycerides[0]!.count + 1;
            double newSum =
                mapSortTriglycerides[0]!.sum + (element.triglycerides);
            mapSortTriglycerides[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortTriglycerides.containsKey(1)) {
            mapSortTriglycerides[1] =
                DataGraph(count: 1, sum: element.triglycerides);
          } else {
            int newCount = mapSortTriglycerides[1]!.count + 1;
            double newSum =
                mapSortTriglycerides[1]!.sum + (element.triglycerides);
            mapSortTriglycerides[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortTriglycerides.containsKey(2)) {
            mapSortTriglycerides[2] =
                DataGraph(count: 1, sum: element.triglycerides);
          } else {
            int newCount = mapSortTriglycerides[2]!.count + 1;
            double newSum =
                mapSortTriglycerides[2]!.sum + (element.triglycerides);
            mapSortTriglycerides[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortTriglycerides.containsKey(3)) {
            mapSortTriglycerides[3] =
                DataGraph(count: 1, sum: element.triglycerides);
          } else {
            int newCount = mapSortTriglycerides[3]!.count + 1;
            double newSum =
                mapSortTriglycerides[3]!.sum + (element.triglycerides);
            mapSortTriglycerides[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortTriglycerides.forEach((key, value) {
        double promTriglycerides = value.sum / value.count;
        listXTriglycerides.add(FlSpot(key.toDouble(), promTriglycerides));
      });
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortTriglycerides = {};

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        if (!mapSortTriglycerides.containsKey(day)) {
          mapSortTriglycerides[day] =
              DataGraph(count: 1, sum: element.triglycerides);
        } else {
          int newCount = mapSortTriglycerides[day]!.count + 1;
          double newSum =
              mapSortTriglycerides[day]!.sum + (element.triglycerides);
          mapSortTriglycerides[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortTriglycerides.forEach((key, value) {
        double promTriglycerides = value.sum / value.count;
        listXTriglycerides.add(FlSpot(key.toDouble(), promTriglycerides));
      });
    }

    switch (rangeGraph[valueSelectedTriglycerides]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //Cholesterol Data
  void getParamsGraphCholesterol(List<ProfileLaboratory> list) {
    listXCholesterol = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortCholesterol = {};

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        if (!mapSortCholesterol.containsKey(month)) {
          mapSortCholesterol[month] =
              DataGraph(count: 1, sum: element.cholesterol);
        } else {
          int newCount = mapSortCholesterol[month]!.count + 1;
          double newSum =
              mapSortCholesterol[month]!.sum + (element.cholesterol);
          mapSortCholesterol[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortCholesterol.forEach((key, value) {
        double promCholesterol = value.sum / value.count;
        listXCholesterol.add(FlSpot(key.toDouble(), promCholesterol));
      });
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortCholesterol = {};
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortCholesterol.containsKey(0)) {
            mapSortCholesterol[0] =
                DataGraph(count: 1, sum: element.cholesterol);
          } else {
            int newCount = mapSortCholesterol[0]!.count + 1;
            double newSum = mapSortCholesterol[0]!.sum + (element.cholesterol);
            mapSortCholesterol[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortCholesterol.containsKey(1)) {
            mapSortCholesterol[1] =
                DataGraph(count: 1, sum: element.cholesterol);
          } else {
            int newCount = mapSortCholesterol[1]!.count + 1;
            double newSum = mapSortCholesterol[1]!.sum + (element.cholesterol);
            mapSortCholesterol[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortCholesterol.containsKey(2)) {
            mapSortCholesterol[2] =
                DataGraph(count: 1, sum: element.cholesterol);
          } else {
            int newCount = mapSortCholesterol[2]!.count + 1;
            double newSum = mapSortCholesterol[2]!.sum + (element.cholesterol);
            mapSortCholesterol[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortCholesterol.containsKey(3)) {
            mapSortCholesterol[3] =
                DataGraph(count: 1, sum: element.cholesterol);
          } else {
            int newCount = mapSortCholesterol[3]!.count + 1;
            double newSum = mapSortCholesterol[3]!.sum + (element.cholesterol);
            mapSortCholesterol[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortCholesterol.forEach((key, value) {
        double promCholesterol = value.sum / value.count;
        listXCholesterol.add(FlSpot(key.toDouble(), promCholesterol));
      });
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortCholesterol = {};

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        if (!mapSortCholesterol.containsKey(day)) {
          mapSortCholesterol[day] =
              DataGraph(count: 1, sum: element.cholesterol);
        } else {
          int newCount = mapSortCholesterol[day]!.count + 1;
          double newSum = mapSortCholesterol[day]!.sum + (element.cholesterol);
          mapSortCholesterol[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortCholesterol.forEach((key, value) {
        double promCholesterol = value.sum / value.count;
        listXCholesterol.add(FlSpot(key.toDouble(), promCholesterol));
      });
    }

    switch (rangeGraph[valueSelectedCholesterol]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //Hemoglobin Data
  void getParamsGraphHemoglobin(List<ProfileLaboratory> list) {
    listXHemoglobin = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortHemoglobin = {};

      for (var element in list) {
        var month = DateTime.parse(element.createdAt).month;

        if (!mapSortHemoglobin.containsKey(month)) {
          mapSortHemoglobin[month] =
              DataGraph(count: 1, sum: element.hemoglobin);
        } else {
          int newCount = mapSortHemoglobin[month]!.count + 1;
          double newSum = mapSortHemoglobin[month]!.sum + (element.hemoglobin);
          mapSortHemoglobin[month] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortHemoglobin.forEach((key, value) {
        double promHemoglobin = value.sum / value.count;
        listXHemoglobin.add(FlSpot(key.toDouble(), promHemoglobin));
      });
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortHemoglobin = {};
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortHemoglobin.containsKey(0)) {
            mapSortHemoglobin[0] = DataGraph(count: 1, sum: element.hemoglobin);
          } else {
            int newCount = mapSortHemoglobin[0]!.count + 1;
            double newSum = mapSortHemoglobin[0]!.sum + (element.hemoglobin);
            mapSortHemoglobin[0] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 7))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortHemoglobin.containsKey(1)) {
            mapSortHemoglobin[1] = DataGraph(count: 1, sum: element.hemoglobin);
          } else {
            int newCount = mapSortHemoglobin[1]!.count + 1;
            double newSum = mapSortHemoglobin[1]!.sum + (element.hemoglobin);
            mapSortHemoglobin[1] = DataGraph(count: newCount, sum: newSum);
          }
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(DateTime.parse(element.createdAt))) {
          if (!mapSortHemoglobin.containsKey(2)) {
            mapSortHemoglobin[2] = DataGraph(count: 1, sum: element.hemoglobin);
          } else {
            int newCount = mapSortHemoglobin[2]!.count + 1;
            double newSum = mapSortHemoglobin[2]!.sum + (element.hemoglobin);
            mapSortHemoglobin[2] = DataGraph(count: newCount, sum: newSum);
          }
        } else {
          if (!mapSortHemoglobin.containsKey(3)) {
            mapSortHemoglobin[3] = DataGraph(count: 1, sum: element.hemoglobin);
          } else {
            int newCount = mapSortHemoglobin[3]!.count + 1;
            double newSum = mapSortHemoglobin[3]!.sum + (element.hemoglobin);
            mapSortHemoglobin[3] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      mapSortHemoglobin.forEach((key, value) {
        double promHemoglobin = value.sum / value.count;
        listXHemoglobin.add(FlSpot(key.toDouble(), promHemoglobin));
      });
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortHemoglobin = {};

      for (var element in list) {
        var day = DateTime.parse(element.createdAt).day;

        if (!mapSortHemoglobin.containsKey(day)) {
          mapSortHemoglobin[day] = DataGraph(count: 1, sum: element.hemoglobin);
        } else {
          int newCount = mapSortHemoglobin[day]!.count + 1;
          double newSum = mapSortHemoglobin[day]!.sum + (element.hemoglobin);
          mapSortHemoglobin[day] = DataGraph(count: newCount, sum: newSum);
        }
      }

      mapSortHemoglobin.forEach((key, value) {
        double promHemoglobin = value.sum / value.count;
        listXHemoglobin.add(FlSpot(key.toDouble(), promHemoglobin));
      });
    }

    switch (rangeGraph[valueSelectedHemoglobin]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }

  //UricAcid Data
  void getParamsGraphUricAcid(List<ProfileLaboratory> list) {
    listXUricAcid = [];

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    void calculateMonthlyAverages() {
      Map<int, DataGraph> mapSortUricAcid = {};

      for (var element in list) {
        if (element.uricAcid != null && element.uricAcid != 0) {
          var month = DateTime.parse(element.createdAt).month;
          if (!mapSortUricAcid.containsKey(month)) {
            mapSortUricAcid[month] =
                DataGraph(count: 1, sum: element.uricAcid!);
          } else {
            int newCount = mapSortUricAcid[month]!.count + 1;
            double newSum = mapSortUricAcid[month]!.sum + (element.uricAcid!);
            mapSortUricAcid[month] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      if (mapSortUricAcid.isNotEmpty) {
        mapSortUricAcid.forEach((key, value) {
          double promUricAcid = value.sum / value.count;
          listXUricAcid.add(FlSpot(key.toDouble(), promUricAcid));
        });
      }
    }

    void calculate1MonthAverage() {
      Map<int, DataGraph> mapSortUricAcid = {};
      DateTime dateInit =
          (DateTime.parse(list[0].createdAt)).add(const Duration(days: 7));

      for (var element in list) {
        if (element.uricAcid != null) {
          if (dateInit.isAfter(DateTime.parse(element.createdAt))) {
            if (!mapSortUricAcid.containsKey(0)) {
              mapSortUricAcid[0] = DataGraph(count: 1, sum: element.uricAcid!);
            } else {
              int newCount = mapSortUricAcid[0]!.count + 1;
              double newSum = mapSortUricAcid[0]!.sum + (element.uricAcid!);
              mapSortUricAcid[0] = DataGraph(count: newCount, sum: newSum);
            }
          } else if (dateInit
              .add(const Duration(days: 7))
              .isAfter(DateTime.parse(element.createdAt))) {
            if (!mapSortUricAcid.containsKey(1)) {
              mapSortUricAcid[1] = DataGraph(count: 1, sum: element.uricAcid!);
            } else {
              int newCount = mapSortUricAcid[1]!.count + 1;
              double newSum = mapSortUricAcid[1]!.sum + (element.uricAcid!);
              mapSortUricAcid[1] = DataGraph(count: newCount, sum: newSum);
            }
          } else if (dateInit
              .add(const Duration(days: 14))
              .isAfter(DateTime.parse(element.createdAt))) {
            if (!mapSortUricAcid.containsKey(2)) {
              mapSortUricAcid[2] = DataGraph(count: 1, sum: element.uricAcid!);
            } else {
              int newCount = mapSortUricAcid[2]!.count + 1;
              double newSum = mapSortUricAcid[2]!.sum + (element.uricAcid!);
              mapSortUricAcid[2] = DataGraph(count: newCount, sum: newSum);
            }
          } else {
            if (!mapSortUricAcid.containsKey(3)) {
              mapSortUricAcid[3] = DataGraph(count: 1, sum: element.uricAcid!);
            } else {
              int newCount = mapSortUricAcid[3]!.count + 1;
              double newSum = mapSortUricAcid[3]!.sum + (element.uricAcid!);
              mapSortUricAcid[3] = DataGraph(count: newCount, sum: newSum);
            }
          }
        }
      }

      if (mapSortUricAcid.isNotEmpty) {
        mapSortUricAcid.forEach((key, value) {
          double promUricAcid = value.sum / value.count;
          listXUricAcid.add(FlSpot(key.toDouble(), promUricAcid));
        });
      }
    }

    void calculateWeekAverage() {
      Map<int, DataGraph> mapSortUricAcid = {};

      for (var element in list) {
        if (element.uricAcid != null) {
          var day = DateTime.parse(element.createdAt).day;

          if (!mapSortUricAcid.containsKey(day)) {
            mapSortUricAcid[day] = DataGraph(count: 1, sum: element.uricAcid!);
          } else {
            int newCount = mapSortUricAcid[day]!.count + 1;
            double newSum = mapSortUricAcid[day]!.sum + (element.uricAcid!);
            mapSortUricAcid[day] = DataGraph(count: newCount, sum: newSum);
          }
        }
      }

      if (mapSortUricAcid.isNotEmpty) {
        mapSortUricAcid.forEach((key, value) {
          double promUricAcid = value.sum / value.count;
          listXUricAcid.add(FlSpot(key.toDouble(), promUricAcid));
        });
      }
    }

    switch (rangeGraph[valueSelectedUricAcid]) {
      case "WEEK":
        calculateWeekAverage();
        break;
      case "MONTH":
        calculate1MonthAverage();
        break;
      case "HALF_YEAR":
        calculateMonthlyAverages();
        break;
      case "YEAR":
        calculateMonthlyAverages();
        break;
      default:
    }
  }
}
