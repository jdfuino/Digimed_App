import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/widgets/card_digimed.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/historic_patients_controller.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_cholesterol.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_glucose.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_hemoglobin.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_triglycerides.dart';
import 'package:digimed/app/presentation/pages/historic/admin/view/widget/graph_uric_acid.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LabTab extends StatelessWidget {
  const LabTab({super.key});

  @override
  Widget build(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    final Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(right: 24, left: 24, top: 16, bottom: 16),
        child: Column(
          children: [
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Glucemia",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      const Spacer(),
                      controller.state.glucoseDataState.when(loading: () {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }, failed: (failed) {
                        return _dropMenuGlucose(context);
                      }, loaded: (_) {
                        return _dropMenuGlucose(context);
                      }, nullData: () {
                        return _dropMenuGlucose(context);
                      })
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                controller.state.glucoseDataState.when(
                  loading: () {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                  failed: (_) {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  nullData: () {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  loaded: (list) {
                    if (list != null && list.isNotEmpty) {
                      return const GraphGlucose();
                    } else {
                      return errorMessage();
                    }
                  },
                )
              ],
            )),
            const SizedBox(
              height: 16,
            ),
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Triglicéridos",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      const Spacer(),
                      controller.state.triglyceridesDataState.when(loading: () {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }, failed: (failed) {
                        return _dropMenuTriglycerides(context);
                      }, loaded: (_) {
                        return _dropMenuTriglycerides(context);
                      }, nullData: () {
                        return _dropMenuTriglycerides(context);
                      })
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                controller.state.triglyceridesDataState.when(
                  loading: () {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                  failed: (_) {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  nullData: () {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  loaded: (list) {
                    if (list != null && list.isNotEmpty) {
                      return const GraphTriglycerides();
                    } else {
                      return errorMessage();
                    }
                  },
                )
              ],
            )),
            const SizedBox(
              height: 16,
            ),
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Colesterol No-HDL",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      const Spacer(),
                      controller.state.cholesterolDataState.when(loading: () {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }, failed: (failed) {
                        return _dropMenuCholesterol(context);
                      }, loaded: (_) {
                        return _dropMenuCholesterol(context);
                      }, nullData: () {
                        return _dropMenuCholesterol(context);
                      })
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                controller.state.cholesterolDataState.when(
                  loading: () {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                  failed: (_) {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  nullData: () {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  loaded: (list) {
                    if (list != null && list.isNotEmpty) {
                      return const GraphCholesterol();
                    } else {
                      return errorMessage();
                    }
                  },
                )
              ],
            )),
            const SizedBox(
              height: 16,
            ),
            CardDigimed(
                child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: AppColors.backgroundColor,
                        radius: 5,
                      ),
                      const SizedBox(
                        width: 8,
                      ),
                      Text(
                        "Hemoglobina (g/dL)",
                        style: AppTextStyle.normalContentTextStyle,
                      ),
                      const Spacer(),
                      controller.state.hemoglobinDataState.when(
                        loading: () {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        },
                        failed: (failed) {
                          return _dropMenuHemoglobin(context);
                        },
                        loaded: (_) {
                          return _dropMenuHemoglobin(context);
                        },
                        nullData: () {
                          return _dropMenuHemoglobin(context);
                        },
                      )
                    ],
                  ),
                ),
                const SizedBox(
                  height: 16,
                ),
                controller.state.hemoglobinDataState.when(
                  loading: () {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  },
                  failed: (_) {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  nullData: () {
                    return Container(
                      child: errorMessage(),
                    );
                  },
                  loaded: (list) {
                    if (list != null && list.isNotEmpty) {
                      return const GraphHemoglobin();
                    } else {
                      return errorMessage();
                    }
                  },
                )
              ],
            )),
            const SizedBox(
              height: 16,
            ),
            CardDigimed(
              child: Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(right: 16, left: 16, top: 16),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: AppColors.backgroundColor,
                          radius: 5,
                        ),
                        SizedBox(
                          width: 8,
                        ),
                        Text(
                          "Ácido úrico",
                          style: AppTextStyle.normalContentTextStyle,
                        ),
                        const Spacer(),
                        controller.state.uricAcidDataState.when(
                          loading: () {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          },
                          failed: (failed) {
                            return _dropMenuUricAcid(context);
                          },
                          loaded: (_) {
                            return _dropMenuUricAcid(context);
                          },
                          nullData: () {
                            return _dropMenuUricAcid(context);
                          },
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 16,
                  ),
                  controller.state.uricAcidDataState.when(
                    loading: () {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    },
                    failed: (_) {
                      return Container(
                        child: errorMessage(),
                      );
                    },
                    nullData: () {
                      return Container(
                        child: errorMessage(),
                      );
                    },
                    loaded: (list) {
                      if (list != null && list.isNotEmpty) {
                        return const GraphUricAcid();
                      } else {
                        return errorMessage();
                      }
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 32,
            ),
          ],
        ),
      ),
    );
  }

  Widget _dropMenuGlucose(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: AppColors.buttonSelectedRangeColor,
          child: Row(
            children: <Widget>[
              const Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedGlucose,
                  style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(
                width: 8,
              )
            ],
          ),
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedGlucose = value;
        controller.getDataGlucose(
            glucoseDataState: const GlucoseDataStateLoading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.transparent,
              child: ListTile(
                title: Text(value),
                leading: Radio<String>(
                  value: value,
                  groupValue: controller.valueSelectedGlucose,
                  onChanged: (value) {
                    if (value != null) {
                      controller.valueSelectedGlucose = value;
                      controller.getDataGlucose(
                          glucoseDataState: const GlucoseDataStateLoading());
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          );
        }).toList();
      },
    );
  }

  Widget _dropMenuTriglycerides(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: AppColors.buttonSelectedRangeColor,
          child: Row(
            children: <Widget>[
              const Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedTriglycerides,
                  style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(
                width: 8,
              )
            ],
          ),
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedTriglycerides = value;
        controller.getDataTriglycerides(
            triglyceridesDataState: const TriglyceridesDataState.loading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.transparent,
              child: ListTile(
                title: Text(value),
                leading: Radio<String>(
                  value: value,
                  groupValue: controller.valueSelectedTriglycerides,
                  onChanged: (value) {
                    if (value != null) {
                      controller.valueSelectedTriglycerides = value;
                      controller.getDataTriglycerides(
                          triglyceridesDataState:
                              const TriglyceridesDataState.loading());
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          );
        }).toList();
      },
    );
  }

  Widget _dropMenuCholesterol(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: AppColors.buttonSelectedRangeColor,
          child: Row(
            children: <Widget>[
              const Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedCholesterol,
                  style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(
                width: 8,
              )
            ],
          ),
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedCholesterol = value;
        controller.getDataCholesterol(
            cholesterolDataState: const CholesterolDataStateLoading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.transparent,
              child: ListTile(
                title: Text(value),
                leading: Radio<String>(
                  value: value,
                  groupValue: controller.valueSelectedCholesterol,
                  onChanged: (value) {
                    if (value != null) {
                      controller.valueSelectedCholesterol = value;
                      controller.getDataCholesterol(
                          cholesterolDataState:
                              const CholesterolDataStateLoading());
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          );
        }).toList();
      },
    );
  }

  Widget _dropMenuHemoglobin(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: AppColors.buttonSelectedRangeColor,
          child: Row(
            children: <Widget>[
              const Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedHemoglobin,
                  style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(
                width: 8,
              )
            ],
          ),
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedHemoglobin = value;
        controller.getDataHemoglobin(
            hemoglobinDataState: const HemoglobinDataStateLoading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.transparent,
              child: ListTile(
                title: Text(value),
                leading: Radio<String>(
                  value: value,
                  groupValue: controller.valueSelectedHemoglobin,
                  onChanged: (value) {
                    if (value != null) {
                      controller.valueSelectedHemoglobin = value;
                      controller.getDataHemoglobin(
                          hemoglobinDataState:
                              const HemoglobinDataStateLoading());
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          );
        }).toList();
      },
    );
  }

  Widget _dropMenuUricAcid(BuildContext context) {
    final HistoricPatientsController controller = Provider.of(context);
    return PopupMenuButton<String>(
      child: SizedBox(
        height: 40,
        child: Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: AppColors.buttonSelectedRangeColor,
          child: Row(
            children: <Widget>[
              const Icon(
                Icons.arrow_drop_down,
                color: AppColors.backgroundColor,
              ),
              Text(controller.valueSelectedUricAcid,
                  style: AppTextStyle.normalBlueTextStyle),
              const SizedBox(
                width: 8,
              )
            ],
          ),
        ),
      ),
      onSelected: (String value) {
        controller.valueSelectedUricAcid = value;
        controller.getDataUricAcid(
            uricAcidDataState: const UricAcidDataStateLoading());
      },
      itemBuilder: (BuildContext context) {
        return ["1 semana", "1 mes", "6 meses", "1 año"].map((String value) {
          return PopupMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.transparent,
              child: ListTile(
                title: Text(value),
                leading: Radio<String>(
                  value: value,
                  groupValue: controller.valueSelectedUricAcid,
                  onChanged: (value) {
                    if (value != null) {
                      controller.valueSelectedUricAcid = value;
                      controller.getDataUricAcid(
                          uricAcidDataState: const UricAcidDataStateLoading());
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
