import 'package:flutter/material.dart';

class TopicDigimed {
  static const String appName = "digimed";
  static const String allUsers = "all";
  static const String topicProperty = "property_";
}