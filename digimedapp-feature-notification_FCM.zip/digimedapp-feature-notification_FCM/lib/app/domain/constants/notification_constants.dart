enum NotificationCategory {
  propertyUpdateReminder('property_update_reminder'),
  propertySuspensionWarning('property_suspension_warning'),
  priceChangeAlert('price_change_alert'),
  userReengagement('user_reengagement'),
  promotions('promotions'),
  newPropertyMatch('new_property_match'),
  likedPropertySold('liked_property_sold');

  final String value;
  const NotificationCategory(this.value);

  static NotificationCategory fromString(String value) {
    return NotificationCategory.values.firstWhere(
          (e) => e.value == value,
      orElse: () => NotificationCategory.promotions,
    );
  }
}

enum NotificationPriority {
  high('high'),
  normal('normal');

  final String value;
  const NotificationPriority(this.value);
}