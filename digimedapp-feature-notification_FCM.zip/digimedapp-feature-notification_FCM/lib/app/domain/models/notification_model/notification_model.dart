import 'package:digimed/app/domain/constants/notification_constants.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'notification_model.freezed.dart';
part 'notification_model.g.dart';

@freezed
class NotificationModel with _$NotificationModel {
  const factory NotificationModel({
    required String id,
    required String title,
    required String body,
    @Default({}) Map<String, dynamic> data,
    required NotificationCategory category,
    required DateTime createdAt,
    @Default(false) bool isRead,
    String? imageUrl,
    String? propertyId,
    DateTime? readAt,
    DateTime? sentTime,
  }) = _NotificationModel;

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      _$NotificationModelFromJson(json);

  factory NotificationModel.fromRemoteMessage(RemoteMessage message) {
    return NotificationModel(
      id: message.messageId ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: message.notification?.title ?? 'Nueva notificación',
      body: message.notification?.body ?? '',
      data: message.data,
      category: NotificationCategory.fromString(message.data['category'] ?? 'promotions'),
      createdAt: message.sentTime ?? DateTime.now(),
      imageUrl: message.notification?.android?.imageUrl ?? message.notification?.apple?.imageUrl,
      propertyId: message.data['property_id'],
      sentTime: message.sentTime,
    );
  }
}