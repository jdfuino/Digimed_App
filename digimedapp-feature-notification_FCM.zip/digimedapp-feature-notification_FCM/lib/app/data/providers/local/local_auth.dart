import 'package:local_auth/local_auth.dart';

class LocalAuth {
  static final _auth = LocalAuthentication();
  static Future<bool> _canAuth() async =>
      await _auth.canCheckBiometrics || await _auth.isDeviceSupported();

  static Future<bool> authenticate() async {
    try {
      if (!await _canAuth()) return false;
      return await _auth.authenticate(
        localizedReason: "Confirma tu identidad para continuar",
        options: const AuthenticationOptions(
          biometricOnly: true,
          // stickyAuth: true,
          // useErrorDialogs: true,
        ),
      );
    } catch (e) {
      return false;
    }
  }
}

  // static Future<Either<LoginFailure, User>> authenticate(
  //     AuthenticationRepository _authenticationRepository) async {
  //   try {
  //     if (!await _canAuth()) return Left(LoginFailure.unknown());
  //     final bool didAuthenticate = await _auth.authenticate(
  //       localizedReason: "Confirma tu identidad para continuar",
  //       options: const AuthenticationOptions(biometricOnly: true),
  //     );

  //     if (didAuthenticate) {
  //       return await _authenticationRepository.signInWithBiometric("", "");
  //     } else {
  //       return Left(LoginFailure.unknown());
  //     }
  //   } catch (e) {
  //     return Left(LoginFailure.unknown());
  //   }
  // }
