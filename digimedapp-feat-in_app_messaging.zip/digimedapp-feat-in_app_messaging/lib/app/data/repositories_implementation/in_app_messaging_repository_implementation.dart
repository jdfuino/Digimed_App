import 'package:digimed/app/domain/either/either.dart';
import 'package:digimed/app/domain/failures/http_request/http_request_failure.dart';
import 'package:digimed/app/domain/repositories/in_app_messaging_repository.dart';
import 'package:firebase_in_app_messaging/firebase_in_app_messaging.dart';

import '../../domain/globals/logger.dart';

class InAppMessagingRepositoryImplementation
    implements InAppMessagingRepository {
  late final FirebaseInAppMessaging _firebaseInAppMessaging;
  bool _isInitialized = false;

  /// Eventos predefinidos comunes para trigger
  static const String eventAppOpen = 'app_open';
  static const String eventUserEngagement = 'user_engagement';
  static const String eventPurchase = 'purchase';
  static const String eventSignUp = 'sign_up';
  static const String eventLogin = 'login';
  static const String eventTutorialComplete = 'tutorial_complete';

  /// Eventos específicos de aplicación médica
  static const String eventAppointmentBooked = 'appointment_booked';
  static const String eventTestResultsViewed = 'test_results_viewed';
  static const String eventProfileCompleted = 'profile_completed';
  static const String eventMedicationReminder = 'medication_reminder';
  static const String eventHealthTipViewed = 'health_tip_viewed';

  @override
  Future<Either<HttpRequestFailure, bool>> initialize() async {
    try {
      _firebaseInAppMessaging = FirebaseInAppMessaging.instance;

      // Configuraciones iniciales
      await _firebaseInAppMessaging.setAutomaticDataCollectionEnabled(true);
      await _firebaseInAppMessaging.setMessagesSuppressed(false);

      _isInitialized = true;
      logger
          .i('Firebase In-App Messaging Repository inicializado correctamente');

      return Either.right(true);
    } catch (e) {
      logger.e('Error inicializando Firebase In-App Messaging Repository: $e');
      return Either.left(HttpRequestFailure.network());
    }
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerEvent(
      String eventName) async {
    try {
      if (!_isInitialized) {
        logger.w('Firebase In-App Messaging no está inicializado');
        return Either.left(
            HttpRequestFailure.formData('Service not initialized'));
      }

      await _firebaseInAppMessaging.triggerEvent(eventName);
      logger.i('Evento triggeado exitosamente: $eventName');

      return Either.right(true);
    } catch (e) {
      logger.e('Error triggering evento $eventName: $e');
      return Either.left(HttpRequestFailure.network());
    }
  }

  @override
  Future<Either<HttpRequestFailure, bool>> suppressMessages(
      bool suppress) async {
    try {
      if (!_isInitialized) {
        logger.w('Firebase In-App Messaging no está inicializado');
        return Either.left(
            HttpRequestFailure.formData('Service not initialized'));
      }

      await _firebaseInAppMessaging.setMessagesSuppressed(suppress);
      logger.i(
          'Mensajes ${suppress ? "suprimidos" : "habilitados"} exitosamente');

      return Either.right(true);
    } catch (e) {
      logger.e('Error cambiando supresión de mensajes: $e');
      return Either.left(HttpRequestFailure.network());
    }
  }

  @override
  Future<Either<HttpRequestFailure, bool>> setDataCollectionEnabled(
      bool enabled) async {
    try {
      if (!_isInitialized) {
        logger.w('Firebase In-App Messaging no está inicializado');
        return Either.left(
            HttpRequestFailure.formData('Service not initialized'));
      }

      await _firebaseInAppMessaging.setAutomaticDataCollectionEnabled(enabled);
      logger.i(
          'Recolección automática de datos ${enabled ? "habilitada" : "deshabilitada"} exitosamente');

      return Either.right(true);
    } catch (e) {
      logger.e('Error cambiando recolección de datos: $e');
      return Either.left(HttpRequestFailure.network());
    }
  }

  // Métodos de conveniencia para eventos comunes
  @override
  Future<Either<HttpRequestFailure, bool>> triggerAppOpen() async {
    return await triggerEvent(eventAppOpen);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerUserEngagement() async {
    return await triggerEvent(eventUserEngagement);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerLogin() async {
    return await triggerEvent(eventLogin);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerSignUp() async {
    return await triggerEvent(eventSignUp);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerTutorialComplete() async {
    return await triggerEvent(eventTutorialComplete);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerPurchase() async {
    return await triggerEvent(eventPurchase);
  }

  // Métodos específicos para aplicación médica
  @override
  Future<Either<HttpRequestFailure, bool>> triggerAppointmentBooked() async {
    return await triggerEvent(eventAppointmentBooked);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerTestResultsViewed() async {
    return await triggerEvent(eventTestResultsViewed);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerProfileCompleted() async {
    return await triggerEvent(eventProfileCompleted);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerMedicationReminder() async {
    return await triggerEvent(eventMedicationReminder);
  }

  @override
  Future<Either<HttpRequestFailure, bool>> triggerHealthTipViewed() async {
    return await triggerEvent(eventHealthTipViewed);
  }
}
