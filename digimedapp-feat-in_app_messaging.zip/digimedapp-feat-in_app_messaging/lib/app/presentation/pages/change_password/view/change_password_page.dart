import 'package:digimed/app/domain/repositories/authentication_repository.dart';
import 'package:digimed/app/generated/assets.gen.dart';
import 'package:digimed/app/inject_repositories.dart';
import 'package:digimed/app/presentation/global/app_colors.dart';
import 'package:digimed/app/presentation/global/app_text_sytle.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/global/icons/digimed_icon_icons.dart';
import 'package:digimed/app/presentation/global/widgets/banner_logo.dart';
import 'package:digimed/app/presentation/global/widgets/button_digimed.dart';
import 'package:digimed/app/presentation/global/widgets/card_digimed.dart';
import 'package:digimed/app/presentation/pages/change_password/controller/change_password_controller.dart';
import 'package:digimed/app/presentation/pages/change_password/controller/state/change_password_state.dart';
import 'package:digimed/app/presentation/pages/login/views/login_page.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

final _formKey = GlobalKey<FormState>();

class ChangePasswordPage extends StatelessWidget {
  final String email;
  final String otpCode;

  const ChangePasswordPage(
      {super.key, required this.email, required this.otpCode});

  @override
  Widget build(BuildContext context) {
    SessionController session = context.read();
    session.setContext(context);
    final Size size = MediaQuery.of(context).size;
    return ChangeNotifierProvider<ChangePasswordController>(
      create: (_) => ChangePasswordController(
        ChangePasswordState(),
        authenticationRepository: Repositories.authentication,
        sessionController: session,
        email: email,
        otpCode: otpCode,
      ),
      child: Builder(builder: (context) {
        final controller = Provider.of<ChangePasswordController>(context);
        return Scaffold(
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                BannerLogo(),
                Container(
                  width: double.infinity,
                  margin: EdgeInsets.only(right: 24, left: 24),
                  child: Column(
                    children: [
                      Text(
                        "Personaliza tu contraseña",
                        style: AppTextStyle.normal17ContentTextStyle,
                      ),
                      SizedBox(
                        height: 16,
                      ),
                      CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: size.width * 0.20,
                        child: SvgPicture.asset(Assets.svgs.lockDigimed.path),
                      ),
                      SizedBox(
                        height: 16,
                      ),
                      Form(
                          key: _formKey,
                          child: CardDigimed(
                            child: Container(
                              width: double.infinity,
                              margin: EdgeInsets.only(
                                  right: 24, left: 24, top: 24, bottom: 24),
                              child: Column(
                                children: [
                                  TextFormField(
                                    keyboardType: TextInputType.text,
                                    style: AppTextStyle.normalTextStyle2,
                                    autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                    onChanged: (text) {
                                      // controller.onChangedName(text);
                                    },
                                    obscureText:
                                        controller.state.isVisiblePassword,
                                    obscuringCharacter: "*",
                                    decoration: InputDecoration(
                                        filled: true,
                                        fillColor:
                                            AppColors.backgroundSearchColor,
                                        hintText: 'Nueva contraseña',
                                        hintStyle: AppTextStyle.hintTextStyle,
                                        contentPadding:
                                            const EdgeInsets.fromLTRB(
                                                20.0, 15.0, 20.0, 15.0),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide: const BorderSide(
                                              width: 0.2,
                                              color: AppColors
                                                  .backgroundSearchColor),
                                        ),
                                        suffixIcon: IconButton(
                                          icon: Icon(
                                            controller.state.isVisiblePassword
                                                ? DigimedIcon.view
                                                : Icons.visibility,
                                          ),
                                          onPressed: () {
                                            controller
                                                .onVisibilityPasswordChanged(
                                                    !controller.state
                                                        .isVisiblePassword);
                                          },
                                        )),
                                    validator: (text) {
                                      if (text == null || text.isEmpty) {
                                        return "Este campo es obligatorio";
                                      } else if (text.length < 6) {
                                        return "La contraseña debe tener mas de 6 caracteres";
                                      }
                                      return null;
                                    },
                                    onSaved: (text) {
                                      controller.password = text;
                                    },
                                  ),
                                  SizedBox(
                                    height: 16,
                                  ),
                                  TextFormField(
                                    keyboardType: TextInputType.text,
                                    style: AppTextStyle.normalTextStyle2,
                                    autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                    onChanged: (text) {
                                      // controller.onChangedName(text);
                                    },
                                    obscureText:
                                        controller.state.isVisiblePassword,
                                    obscuringCharacter: "*",
                                    decoration: InputDecoration(
                                        filled: true,
                                        fillColor:
                                            AppColors.backgroundSearchColor,
                                        hintText: 'Confirmar contraseña',
                                        hintStyle: AppTextStyle.hintTextStyle,
                                        contentPadding:
                                            const EdgeInsets.fromLTRB(
                                                20.0, 15.0, 20.0, 15.0),
                                        enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          borderSide: const BorderSide(
                                              width: 0.2,
                                              color: AppColors
                                                  .backgroundSearchColor),
                                        ),
                                        suffixIcon: IconButton(
                                          icon: Icon(
                                            controller.state.isVisiblePassword
                                                ? DigimedIcon.view
                                                : Icons.visibility,
                                          ),
                                          onPressed: () {
                                            controller
                                                .onVisibilityPasswordChanged(
                                                    !controller.state
                                                        .isVisiblePassword);
                                          },
                                        )),
                                    validator: (text) {
                                      if (text == null || text.isEmpty) {
                                        return "Este campo es obligatorio";
                                      } else if (text.length < 6) {
                                        return "La contraseña debe tener mas de 6 caracteres";
                                      }
                                      return null;
                                    },
                                    onSaved: (text) {
                                      controller.confirmPassword = text;
                                    },
                                  )
                                ],
                              ),
                            ),
                          )),
                      SizedBox(
                        height: 32,
                      ),
                      // se esta simulando el proceso de cambiar la contraseña y cargar el boton 5seg revisar el controlador de esta page.
                      controller.state.fetching
                          ? CircularProgressIndicator()
                          : ButtonDigimed(
                              child: Text(
                                "Siguiente",
                                style: AppTextStyle
                                    .normalWhite15W600ContentTextStyle,
                              ),
                              onTab: () async {
                                _formKey.currentState!.save();
                                final isValid =
                                    _formKey.currentState!.validate();
                                if (isValid) {
                                  if (controller.password ==
                                      controller.confirmPassword!) {
                                    final result =
                                        await controller.changePassword();
                                    if (controller.showLogin!) {
                                      Navigator.pop(context);
                                    }
                                  } else {
                                    showToast("las contraseñas no coinciden");
                                  }
                                }
                              },
                            ),
                      SizedBox(
                        height: 16,
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}
