import 'package:digimed/app/domain/repositories/accountRepository.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/global/state_notifier.dart';
import 'package:digimed/app/presentation/pages/treatments/controller/state/treatment_state.dart';

class TreatmentController extends StateNotifier<TreatmentState> {
  final AccountRepository accountRepository;
  final SessionController sessionController;

  TreatmentController(super._state,
      {required this.accountRepository, required this.sessionController});

  Future<void> onRefresh({TreatmentState? notificationState}) async {
    if (notificationState == null) {
      state = state.copyWith(
          treatmentsFetchState: const TreatmentsFetchStateLoading());
    }

    final result =
        await accountRepository.getMePatient(sessionController.state!);

    result.when(left: (_) {
      state = state.copyWith(
          treatmentsFetchState: const TreatmentsFetchStateLoaded([]));
    }, right: (patient) {
      sessionController.patients = patient;
      state = state.copyWith(
          treatmentsFetchState:
              TreatmentsFetchStateLoaded(patient!.treatments));
    });
  }
}
