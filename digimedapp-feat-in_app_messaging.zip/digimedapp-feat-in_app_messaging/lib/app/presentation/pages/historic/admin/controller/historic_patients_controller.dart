import 'package:digimed/app/domain/globals/logger.dart';
import 'package:digimed/app/domain/models/data_graph/data_graph.dart';
import 'package:digimed/app/domain/models/profile_cardiovascular/profile_cardiovascular.dart';
import 'package:digimed/app/domain/models/profile_laboratory/profile_laboratory.dart';
import 'package:digimed/app/domain/models/uric_acid_fake/uric_acid_fake.dart';
import 'package:digimed/app/domain/repositories/accountRepository.dart';
import 'package:digimed/app/presentation/global/controllers/session_controller.dart';
import 'package:digimed/app/presentation/global/state_notifier.dart';
import 'package:digimed/app/presentation/pages/historic/admin/controller/state/historic_patients_state.dart';
import 'package:digimed/app/presentation/utils/utils.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:digimed/app/presentation/global/app_colors.dart';

class HistoricPatientsController extends StateNotifier<HistoricPatientsState> {
  final AccountRepository accountRepository;
  final SessionController sessionController;
  final int patientId;

  HistoricPatientsController(super._state,
      {required this.accountRepository,
        required this.sessionController,
        required this.patientId});

  List listOption = ["1 semana", "1 mes", "6 meses", "1 año"];

  //Data Systolic
  String valueSelectedSystolic = "6 meses";
  List<BarChartGroupData> listBarDataSystolic = [];
  List<BarChartGroupData> listBarDataDiastolic = [];

  //double scaleNew = 1;
  double promSistolica = 0;

  //Data Diastolic
  double promDiastolic = 0;

  //Data Heart Rate
  String valueSelectedRate = "6 meses";
  List<BarChartGroupData> listBarDataRate = [];
  double promRate = 0;

  //Data Glucose
  String valueSelectedGlucose = "6 meses";
  List<BarChartGroupData> listBarDataGlucose = [];
  double promGlucose = 0;

  //Data Triglycerides
  String valueSelectedTriglycerides = "6 meses";
  List<BarChartGroupData> listBarDataTriglycerides = [];
  double promTriglycerides = 0;

  //Data Cholesterol
  String valueSelectedCholesterol = "6 meses";
  List<BarChartGroupData> listBarDataCholesterol = [];
  double promCholesterol = 0;

  //Data Hemoglobin
  String valueSelectedHemoglobin = "6 meses";
  List<BarChartGroupData> listBarDataHemoglobin = [];
  double promHemoglobin = 0;

  //Data UricAcid
  String valueSelectedUricAcid = "6 meses";
  List<BarChartGroupData> listBarDataUricAcid = [];
  double promUricAcid = 0;

  Future<void> init() async {
    await getDataBloodPressure();
    await getDataHeartFrequency();
    await getDataGlucose();
    await getDataTriglycerides();
    await getDataCholesterol();
    await getDataHemoglobin();
    await getDataUricAcid();
  }

  Future<void> getDataBloodPressure(
      {BloodPressureDataState? bloodPressureDataState}) async {
    if (bloodPressureDataState != null) {
      state = state.copyWith(bloodPressureDataState: bloodPressureDataState);
    }

    final result = await accountRepository.getDataBloodPressure(
        patientId, rangeGraph[valueSelectedSystolic]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          bloodPressureDataState: BloodPressureDataState.failed(failed));
    }, right: (list) {
      print(list);
      if (list != null) {
        getParamsGraphSystolic(list);
        return state.copyWith(
            bloodPressureDataState: BloodPressureDataState.loaded(list));
      }
      return state.copyWith(
          bloodPressureDataState: const BloodPressureDataState.nullData());
    });
  }

  Future<void> getDataHeartFrequency(
      {HeartFrequencyDataState? heartFrequencyDataState}) async {
    if (heartFrequencyDataState != null) {
      state = state.copyWith(heartFrequencyDataState: heartFrequencyDataState);
    }

    final result = await accountRepository.getDataHeartFrequency(
        patientId, rangeGraph[valueSelectedRate]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          heartFrequencyDataState: HeartFrequencyDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphHearRate(list);
        return state.copyWith(
            heartFrequencyDataState: HeartFrequencyDataState.loaded(list));
      }
      return state.copyWith(
          heartFrequencyDataState: const HeartFrequencyDataState.nullData());
    });
  }

  Future<void> getDataGlucose({GlucoseDataState? glucoseDataState}) async {
    if (glucoseDataState != null) {
      state = state.copyWith(glucoseDataState: glucoseDataState);
    }
    final result = await accountRepository.getDataGlucose(
        patientId, rangeGraph[valueSelectedGlucose]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(glucoseDataState: GlucoseDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphGlucose(list);
        return state.copyWith(glucoseDataState: GlucoseDataState.loaded(list));
      }
      return state.copyWith(
          glucoseDataState: const GlucoseDataState.nullData());
    });
  }

  Future<void> getDataTriglycerides(
      {TriglyceridesDataState? triglyceridesDataState}) async {
    if (triglyceridesDataState != null) {
      state = state.copyWith(triglyceridesDataState: triglyceridesDataState);
    }

    final result = await accountRepository.getDataTriglycerides(
        patientId, rangeGraph[valueSelectedTriglycerides]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          triglyceridesDataState: TriglyceridesDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphTriglycerides(list);
        return state.copyWith(
            triglyceridesDataState: TriglyceridesDataState.loaded(list));
      }
      return state.copyWith(
          triglyceridesDataState: const TriglyceridesDataState.nullData());
    });
  }

  Future<void> getDataCholesterol(
      {CholesterolDataState? cholesterolDataState}) async {
    if (cholesterolDataState != null) {
      state = state.copyWith(cholesterolDataState: cholesterolDataState);
    }

    final result = await accountRepository.getDataCholesterol(
        patientId, rangeGraph[valueSelectedCholesterol]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          cholesterolDataState: CholesterolDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphCholesterol(list);
        return state.copyWith(
            cholesterolDataState: CholesterolDataState.loaded(list));
      }
      return state.copyWith(
          cholesterolDataState: const CholesterolDataState.nullData());
    });
  }

  Future<void> getDataHemoglobin(
      {HemoglobinDataState? hemoglobinDataState}) async {
    if (hemoglobinDataState != null) {
      state = state.copyWith(hemoglobinDataState: hemoglobinDataState);
    }

    final result = await accountRepository.getDataHemoglobin(
        patientId, rangeGraph[valueSelectedHemoglobin]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          hemoglobinDataState: HemoglobinDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphHemoglobin(list);
        return state.copyWith(
            hemoglobinDataState: HemoglobinDataState.loaded(list));
      }
      return state.copyWith(
          hemoglobinDataState: const HemoglobinDataState.nullData());
    });
  }

  Future<void> getDataUricAcid({UricAcidDataState? uricAcidDataState}) async {
    if (uricAcidDataState != null) {
      state = state.copyWith(uricAcidDataState: uricAcidDataState);
    }

    final result = await accountRepository.getDataUricAcid(
        patientId, rangeGraph[valueSelectedUricAcid]!);

    state = result.when(left: (failed) {
      failed.maybeWhen(
          tokenInvalided: () {
            sessionController.globalCloseSession();
          },
          orElse: () {});
      return state.copyWith(
          uricAcidDataState: UricAcidDataState.failed(failed));
    }, right: (list) {
      if (list != null) {
        getParamsGraphUricAcid(list);
        if (listBarDataUricAcid.isEmpty) {
          return state.copyWith(
              uricAcidDataState: const UricAcidDataState.nullData());
        }
        return state.copyWith(
            uricAcidDataState: UricAcidDataState.loaded(list));
      }
      return state.copyWith(
          uricAcidDataState: const UricAcidDataState.nullData());
    });
  }

  //Systolic and Diastolic Data - Optimized function
  void getParamsGraphSystolic(List<ProfileCardiovascular> list) {
    listBarDataSystolic = [];
    listBarDataDiastolic = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    logger.i("getParamsGraphSystolic: ${list.length} records found");
    for (var element in list) {
      logger.i(
          "Systolic: ${element.systolicPressure}, Diastolic: ${element
              .diastolicPressure} , Date: ${element.createdAt}");
    }

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedSystolic]) {
      case "WEEK":
        _generateWeeklyData(list);
        break;
      case "MONTH":
        _generateMonthlyData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsData(list);
        break;
      default:
        _generateSixMonthsData(list);
    }

    // Calcular promedios generales a partir de las listas de BarChartGroupData
    _calculateOverallAverages();
  }

  // Generar datos por día (para rango de 1 semana)
  void _generateWeeklyData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> systolicByDay = {};
    Map<int, List<double>> diastolicByDay = {};

    // Agrupar datos por día
    for (var element in list) {
      if (element.systolicPressure != null &&
          element.diastolicPressure != null) {
        int day = DateTime
            .parse(element.createdAt)
            .day;

        systolicByDay.putIfAbsent(day, () => []).add(element.systolicPressure!);
        diastolicByDay
            .putIfAbsent(day, () => [])
            .add(element.diastolicPressure!);
      }
    }

    // Generar BarChartGroupData con promedios por día
    int index = 0;
    List<int> sortedDays = systolicByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      // Promedio sistólico del día
      double avgSystolic = systolicByDay[day]!.reduce((a, b) => a + b) /
          systolicByDay[day]!.length;
      listBarDataSystolic.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgSystolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );

      // Promedio diastólico del día
      double avgDiastolic = diastolicByDay[day]!.reduce((a, b) => a + b) /
          diastolicByDay[day]!.length;
      listBarDataDiastolic.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgDiastolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );

      index++;
    }
  }

  // Generar datos por semana (para rango de 1 mes)
  void _generateMonthlyData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> systolicByWeek = {};
    Map<int, List<double>> diastolicByWeek = {};

    DateTime dateInit =
    DateTime.parse(list[0].createdAt).add(const Duration(days: 7));

    // Agrupar datos por semana
    for (var element in list) {
      if (element.systolicPressure != null &&
          element.diastolicPressure != null) {
        DateTime elementDate = DateTime.parse(element.createdAt);
        int weekIndex;

        if (dateInit.isAfter(elementDate)) {
          weekIndex = 0;
        } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
          weekIndex = 1;
        } else if (dateInit
            .add(const Duration(days: 14))
            .isAfter(elementDate)) {
          weekIndex = 2;
        } else {
          weekIndex = 3;
        }

        systolicByWeek
            .putIfAbsent(weekIndex, () => [])
            .add(element.systolicPressure!);
        diastolicByWeek
            .putIfAbsent(weekIndex, () => [])
            .add(element.diastolicPressure!);
      }
    }

    // Generar BarChartGroupData con promedios por semana
    List<int> sortedWeeks = systolicByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      // Promedio sistólico de la semana
      double avgSystolic = systolicByWeek[week]!.reduce((a, b) => a + b) /
          systolicByWeek[week]!.length;
      listBarDataSystolic.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgSystolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );

      // Promedio diastólico de la semana
      double avgDiastolic = diastolicByWeek[week]!.reduce((a, b) => a + b) /
          diastolicByWeek[week]!.length;
      listBarDataDiastolic.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgDiastolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  // Generar datos por mes (para rango de 6 meses)
  void _generateSixMonthsData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> systolicByMonth = {};
    Map<int, List<double>> diastolicByMonth = {};

    // Agrupar datos por mes
    for (var element in list) {
      if (element.systolicPressure != null &&
          element.diastolicPressure != null) {
        int month = DateTime
            .parse(element.createdAt)
            .month;

        systolicByMonth
            .putIfAbsent(month, () => [])
            .add(element.systolicPressure!);
        diastolicByMonth
            .putIfAbsent(month, () => [])
            .add(element.diastolicPressure!);
      }
    }

    // Generar BarChartGroupData con promedios por mes
    int index = 0;
    List<int> sortedMonths = systolicByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      // Promedio sistólico del mes
      double avgSystolic = systolicByMonth[month]!.reduce((a, b) => a + b) /
          systolicByMonth[month]!.length;
      listBarDataSystolic.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgSystolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );

      // Promedio diastólico del mes
      double avgDiastolic = diastolicByMonth[month]!.reduce((a, b) => a + b) /
          diastolicByMonth[month]!.length;
      listBarDataDiastolic.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgDiastolic,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );

      index++;
    }
  }

  // Calcular promedios generales a partir de las listas de BarChartGroupData
  void _calculateOverallAverages() {
    // Calcular promedio sistólico
    if (listBarDataSystolic.isNotEmpty) {
      double totalSystolic = 0;
      for (var barGroup in listBarDataSystolic) {
        totalSystolic += barGroup.barRods.first.toY;
      }
      promSistolica = totalSystolic / listBarDataSystolic.length;
    } else {
      promSistolica = 0;
    }

    // Calcular promedio diastólico
    if (listBarDataDiastolic.isNotEmpty) {
      double totalDiastolic = 0;
      for (var barGroup in listBarDataDiastolic) {
        totalDiastolic += barGroup.barRods.first.toY;
      }
      promDiastolic = totalDiastolic / listBarDataDiastolic.length;
    } else {
      promDiastolic = 0;
    }
  }

  // Función optimizada para obtener datos de barras sistólicas
  List<BarChartGroupData> getBarDataBarGroupsSystolic(
      List<ProfileCardiovascular> list) {
    return listBarDataSystolic;
  }

  // Nueva función para obtener datos de barras diastólicas
  List<BarChartGroupData> getBarDataBarGroupsDiastolic(
      List<ProfileCardiovascular> list) {
    return listBarDataDiastolic;
  }

  //Heart Rate Data - Optimized function
  void getParamsGraphHearRate(List<ProfileCardiovascular> list) {
    listBarDataRate = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedRate]) {
      case "WEEK":
        _generateWeeklyHeartRateData(list);
        break;
      case "MONTH":
        _generateMonthlyHeartRateData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsHeartRateData(list);
        break;
      default:
        _generateSixMonthsHeartRateData(list);
    }

    // Calcular promedio general
    _calculateHeartRateAverage();
  }

  void _generateWeeklyHeartRateData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> heartRateByDay = {};

    for (var element in list) {
      if (element.heartFrequency != null) {
        int day = DateTime
            .parse(element.createdAt)
            .day;
        heartRateByDay.putIfAbsent(day, () => []).add(element.heartFrequency!);
      }
    }

    int index = 0;
    List<int> sortedDays = heartRateByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgHeartRate = heartRateByDay[day]!.reduce((a, b) => a + b) /
          heartRateByDay[day]!.length;
      listBarDataRate.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgHeartRate,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyHeartRateData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> heartRateByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      if (element.heartFrequency != null) {
        DateTime elementDate = DateTime.parse(element.createdAt);
        int weekIndex;

        if (dateInit.isAfter(elementDate)) {
          weekIndex = 0;
        } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
          weekIndex = 1;
        } else
        if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
          weekIndex = 2;
        } else {
          weekIndex = 3;
        }

        heartRateByWeek.putIfAbsent(weekIndex, () => []).add(
            element.heartFrequency!);
      }
    }

    List<int> sortedWeeks = heartRateByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgHeartRate = heartRateByWeek[week]!.reduce((a, b) => a + b) /
          heartRateByWeek[week]!.length;
      listBarDataRate.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgHeartRate,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsHeartRateData(List<ProfileCardiovascular> list) {
    Map<int, List<double>> heartRateByMonth = {};

    for (var element in list) {
      if (element.heartFrequency != null) {
        int month = DateTime
            .parse(element.createdAt)
            .month;
        heartRateByMonth.putIfAbsent(month, () => []).add(
            element.heartFrequency!);
      }
    }

    int index = 0;
    List<int> sortedMonths = heartRateByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgHeartRate = heartRateByMonth[month]!.reduce((a, b) => a + b) /
          heartRateByMonth[month]!.length;
      listBarDataRate.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgHeartRate,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateHeartRateAverage() {
    if (listBarDataRate.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataRate) {
        total += barGroup.barRods.first.toY;
      }
      promRate = total / listBarDataRate.length;
    } else {
      promRate = 0;
    }
  }

  //Glucose Data - Optimized function
  void getParamsGraphGlucose(List<ProfileLaboratory> list) {
    listBarDataGlucose = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedGlucose]) {
      case "WEEK":
        _generateWeeklyGlucoseData(list);
        break;
      case "MONTH":
        _generateMonthlyGlucoseData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsGlucoseData(list);
        break;
      default:
        _generateSixMonthsGlucoseData(list);
    }

    // Calcular promedio general
    _calculateGlucoseAverage();
  }

  void _generateWeeklyGlucoseData(List<ProfileLaboratory> list) {
    Map<int, List<double>> glucoseByDay = {};

    for (var element in list) {
      int day = DateTime
          .parse(element.createdAt)
          .day;
      glucoseByDay.putIfAbsent(day, () => []).add(element.glucose);
    }

    int index = 0;
    List<int> sortedDays = glucoseByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgGlucose = glucoseByDay[day]!.reduce((a, b) => a + b) /
          glucoseByDay[day]!.length;
      listBarDataGlucose.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgGlucose,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyGlucoseData(List<ProfileLaboratory> list) {
    Map<int, List<double>> glucoseByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      DateTime elementDate = DateTime.parse(element.createdAt);
      int weekIndex;

      if (dateInit.isAfter(elementDate)) {
        weekIndex = 0;
      } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
        weekIndex = 1;
      } else if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
        weekIndex = 2;
      } else {
        weekIndex = 3;
      }

      glucoseByWeek.putIfAbsent(weekIndex, () => []).add(element.glucose);
    }

    List<int> sortedWeeks = glucoseByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgGlucose = glucoseByWeek[week]!.reduce((a, b) => a + b) /
          glucoseByWeek[week]!.length;
      listBarDataGlucose.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgGlucose,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsGlucoseData(List<ProfileLaboratory> list) {
    Map<int, List<double>> glucoseByMonth = {};

    for (var element in list) {
      int month = DateTime
          .parse(element.createdAt)
          .month;
      glucoseByMonth.putIfAbsent(month, () => []).add(element.glucose);
    }

    int index = 0;
    List<int> sortedMonths = glucoseByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgGlucose = glucoseByMonth[month]!.reduce((a, b) => a + b) /
          glucoseByMonth[month]!.length;
      listBarDataGlucose.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgGlucose,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateGlucoseAverage() {
    if (listBarDataGlucose.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataGlucose) {
        total += barGroup.barRods.first.toY;
      }
      promGlucose = total / listBarDataGlucose.length;
    } else {
      promGlucose = 0;
    }
  }

  //Triglycerides Data - Optimized function
  void getParamsGraphTriglycerides(List<ProfileLaboratory> list) {
    listBarDataTriglycerides = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedTriglycerides]) {
      case "WEEK":
        _generateWeeklyTriglyceridesData(list);
        break;
      case "MONTH":
        _generateMonthlyTriglyceridesData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsTriglyceridesData(list);
        break;
      default:
        _generateSixMonthsTriglyceridesData(list);
    }

    // Calcular promedio general
    _calculateTriglyceridesAverage();
  }

  void _generateWeeklyTriglyceridesData(List<ProfileLaboratory> list) {
    Map<int, List<double>> triglyceridesByDay = {};

    for (var element in list) {
      int day = DateTime
          .parse(element.createdAt)
          .day;
      triglyceridesByDay.putIfAbsent(day, () => []).add(element.triglycerides);
    }

    int index = 0;
    List<int> sortedDays = triglyceridesByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgTriglycerides = triglyceridesByDay[day]!.reduce((a, b) =>
      a + b) / triglyceridesByDay[day]!.length;
      listBarDataTriglycerides.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgTriglycerides,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyTriglyceridesData(List<ProfileLaboratory> list) {
    Map<int, List<double>> triglyceridesByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      DateTime elementDate = DateTime.parse(element.createdAt);
      int weekIndex;

      if (dateInit.isAfter(elementDate)) {
        weekIndex = 0;
      } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
        weekIndex = 1;
      } else if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
        weekIndex = 2;
      } else {
        weekIndex = 3;
      }

      triglyceridesByWeek.putIfAbsent(weekIndex, () => []).add(
          element.triglycerides);
    }

    List<int> sortedWeeks = triglyceridesByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgTriglycerides = triglyceridesByWeek[week]!.reduce((a, b) =>
      a + b) / triglyceridesByWeek[week]!.length;
      listBarDataTriglycerides.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgTriglycerides,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsTriglyceridesData(List<ProfileLaboratory> list) {
    Map<int, List<double>> triglyceridesByMonth = {};

    for (var element in list) {
      int month = DateTime
          .parse(element.createdAt)
          .month;
      triglyceridesByMonth.putIfAbsent(month, () => []).add(
          element.triglycerides);
    }

    int index = 0;
    List<int> sortedMonths = triglyceridesByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgTriglycerides = triglyceridesByMonth[month]!.reduce((a,
          b) => a + b) / triglyceridesByMonth[month]!.length;
      listBarDataTriglycerides.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgTriglycerides,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateTriglyceridesAverage() {
    if (listBarDataTriglycerides.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataTriglycerides) {
        total += barGroup.barRods.first.toY;
      }
      promTriglycerides = total / listBarDataTriglycerides.length;
    } else {
      promTriglycerides = 0;
    }
  }

  //Cholesterol Data - Optimized function
  void getParamsGraphCholesterol(List<ProfileLaboratory> list) {
    listBarDataCholesterol = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedCholesterol]) {
      case "WEEK":
        _generateWeeklyCholesterolData(list);
        break;
      case "MONTH":
        _generateMonthlyCholesterolData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsCholesterolData(list);
        break;
      default:
        _generateSixMonthsCholesterolData(list);
    }

    // Calcular promedio general
    _calculateCholesterolAverage();
  }

  void _generateWeeklyCholesterolData(List<ProfileLaboratory> list) {
    Map<int, List<double>> cholesterolByDay = {};

    for (var element in list) {
      int day = DateTime
          .parse(element.createdAt)
          .day;
      cholesterolByDay.putIfAbsent(day, () => []).add(element.cholesterol);
    }

    int index = 0;
    List<int> sortedDays = cholesterolByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgCholesterol = cholesterolByDay[day]!.reduce((a, b) => a + b) /
          cholesterolByDay[day]!.length;
      listBarDataCholesterol.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgCholesterol,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyCholesterolData(List<ProfileLaboratory> list) {
    Map<int, List<double>> cholesterolByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      DateTime elementDate = DateTime.parse(element.createdAt);
      int weekIndex;

      if (dateInit.isAfter(elementDate)) {
        weekIndex = 0;
      } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
        weekIndex = 1;
      } else if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
        weekIndex = 2;
      } else {
        weekIndex = 3;
      }

      cholesterolByWeek.putIfAbsent(weekIndex, () => []).add(
          element.cholesterol);
    }

    List<int> sortedWeeks = cholesterolByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgCholesterol = cholesterolByWeek[week]!.reduce((a, b) => a + b) /
          cholesterolByWeek[week]!.length;
      listBarDataCholesterol.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgCholesterol,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsCholesterolData(List<ProfileLaboratory> list) {
    Map<int, List<double>> cholesterolByMonth = {};

    for (var element in list) {
      int month = DateTime
          .parse(element.createdAt)
          .month;
      cholesterolByMonth.putIfAbsent(month, () => []).add(element.cholesterol);
    }

    int index = 0;
    List<int> sortedMonths = cholesterolByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgCholesterol = cholesterolByMonth[month]!.reduce((a, b) =>
      a + b) / cholesterolByMonth[month]!.length;
      listBarDataCholesterol.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgCholesterol,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateCholesterolAverage() {
    if (listBarDataCholesterol.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataCholesterol) {
        total += barGroup.barRods.first.toY;
      }
      promCholesterol = total / listBarDataCholesterol.length;
    } else {
      promCholesterol = 0;
    }
  }

  //Hemoglobin Data - Optimized function
  void getParamsGraphHemoglobin(List<ProfileLaboratory> list) {
    listBarDataHemoglobin = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    logger.i("Hemoglobin: ${list.length} records found");
    for (var element in list) {
      logger.i(
          "Hemoglobin: ${element.hemoglobin}, Date: ${element.createdAt}");
    }

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedHemoglobin]) {
      case "WEEK":
        _generateWeeklyHemoglobinData(list);
        break;
      case "MONTH":
        _generateMonthlyHemoglobinData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsHemoglobinData(list);
        break;
      default:
        _generateSixMonthsHemoglobinData(list);
    }

    // Calcular promedio general
    _calculateHemoglobinAverage();
  }

  void _generateWeeklyHemoglobinData(List<ProfileLaboratory> list) {
    Map<int, List<double>> hemoglobinByDay = {};

    for (var element in list) {
      int day = DateTime
          .parse(element.createdAt)
          .day;
      hemoglobinByDay.putIfAbsent(day, () => []).add(element.hemoglobin);
    }

    int index = 0;
    List<int> sortedDays = hemoglobinByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgHemoglobin = hemoglobinByDay[day]!.reduce((a, b) => a + b) /
          hemoglobinByDay[day]!.length;
      listBarDataHemoglobin.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgHemoglobin,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyHemoglobinData(List<ProfileLaboratory> list) {
    Map<int, List<double>> hemoglobinByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      DateTime elementDate = DateTime.parse(element.createdAt);
      int weekIndex;

      if (dateInit.isAfter(elementDate)) {
        weekIndex = 0;
      } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
        weekIndex = 1;
      } else if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
        weekIndex = 2;
      } else {
        weekIndex = 3;
      }

      hemoglobinByWeek.putIfAbsent(weekIndex, () => []).add(element.hemoglobin);
    }

    List<int> sortedWeeks = hemoglobinByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgHemoglobin = hemoglobinByWeek[week]!.reduce((a, b) => a + b) /
          hemoglobinByWeek[week]!.length;
      listBarDataHemoglobin.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgHemoglobin,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsHemoglobinData(List<ProfileLaboratory> list) {
    Map<int, List<double>> hemoglobinByMonth = {};

    for (var element in list) {
      int month = DateTime
          .parse(element.createdAt)
          .month;
      hemoglobinByMonth.putIfAbsent(month, () => []).add(element.hemoglobin);
    }

    int index = 0;
    List<int> sortedMonths = hemoglobinByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgHemoglobin = hemoglobinByMonth[month]!.reduce((a, b) => a + b) /
          hemoglobinByMonth[month]!.length;
      listBarDataHemoglobin.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgHemoglobin,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateHemoglobinAverage() {
    if (listBarDataHemoglobin.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataHemoglobin) {
        total += barGroup.barRods.first.toY;
      }
      promHemoglobin = total / listBarDataHemoglobin.length;
    } else {
      promHemoglobin = 0;
    }
  }

  //UricAcid Data - Optimized function
  void getParamsGraphUricAcid(List<ProfileLaboratory> list) {
    listBarDataUricAcid = [];

    if (list.isEmpty) return;

    list.sort((a, b) =>
        DateTime.parse(a.createdAt).compareTo(DateTime.parse(b.createdAt)));

    // Generar datos para gráficos de barras según el rango seleccionado
    switch (rangeGraph[valueSelectedUricAcid]) {
      case "WEEK":
        _generateWeeklyUricAcidData(list);
        break;
      case "MONTH":
        _generateMonthlyUricAcidData(list);
        break;
      case "HALF_YEAR":
      case "YEAR":
        _generateSixMonthsUricAcidData(list);
        break;
      default:
        _generateSixMonthsUricAcidData(list);
    }

    // Calcular promedio general
    _calculateUricAcidAverage();
  }

  void _generateWeeklyUricAcidData(List<ProfileLaboratory> list) {
    Map<int, List<double>> uricAcidByDay = {};

    for (var element in list) {
      if (element.uricAcid != null) {
        int day = DateTime
            .parse(element.createdAt)
            .day;
        uricAcidByDay.putIfAbsent(day, () => []).add(element.uricAcid!);
      }
    }

    int index = 0;
    List<int> sortedDays = uricAcidByDay.keys.toList()
      ..sort();

    for (int day in sortedDays) {
      double avgUricAcid = uricAcidByDay[day]!.reduce((a, b) => a + b) /
          uricAcidByDay[day]!.length;
      listBarDataUricAcid.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgUricAcid,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _generateMonthlyUricAcidData(List<ProfileLaboratory> list) {
    Map<int, List<double>> uricAcidByWeek = {};
    DateTime dateInit = DateTime.parse(list[0].createdAt).add(
        const Duration(days: 7));

    for (var element in list) {
      if (element.uricAcid != null) {
        DateTime elementDate = DateTime.parse(element.createdAt);
        int weekIndex;

        if (dateInit.isAfter(elementDate)) {
          weekIndex = 0;
        } else if (dateInit.add(const Duration(days: 7)).isAfter(elementDate)) {
          weekIndex = 1;
        } else
        if (dateInit.add(const Duration(days: 14)).isAfter(elementDate)) {
          weekIndex = 2;
        } else {
          weekIndex = 3;
        }

        uricAcidByWeek.putIfAbsent(weekIndex, () => []).add(element.uricAcid!);
      }
    }

    List<int> sortedWeeks = uricAcidByWeek.keys.toList()
      ..sort();

    for (int week in sortedWeeks) {
      double avgUricAcid = uricAcidByWeek[week]!.reduce((a, b) => a + b) /
          uricAcidByWeek[week]!.length;
      listBarDataUricAcid.add(
        BarChartGroupData(
          x: week,
          barRods: [
            BarChartRodData(
              toY: avgUricAcid,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
    }
  }

  void _generateSixMonthsUricAcidData(List<ProfileLaboratory> list) {
    Map<int, List<double>> uricAcidByMonth = {};

    for (var element in list) {
      if (element.uricAcid != null) {
        int month = DateTime
            .parse(element.createdAt)
            .month;
        uricAcidByMonth.putIfAbsent(month, () => []).add(element.uricAcid!);
      }
    }

    int index = 0;
    List<int> sortedMonths = uricAcidByMonth.keys.toList()
      ..sort();

    for (int month in sortedMonths) {
      double avgUricAcid = uricAcidByMonth[month]!.reduce((a, b) => a + b) /
          uricAcidByMonth[month]!.length;
      listBarDataUricAcid.add(
        BarChartGroupData(
          x: index,
          barRods: [
            BarChartRodData(
              toY: avgUricAcid,
              width: 10,
              color: AppColors.backgroundColor,
            )
          ],
          showingTooltipIndicators: [1],
        ),
      );
      index++;
    }
  }

  void _calculateUricAcidAverage() {
    if (listBarDataUricAcid.isNotEmpty) {
      double total = 0;
      for (var barGroup in listBarDataUricAcid) {
        total += barGroup.barRods.first.toY;
      }
      promUricAcid = total / listBarDataUricAcid.length;
    } else {
      promUricAcid = 0;
    }
  }

}