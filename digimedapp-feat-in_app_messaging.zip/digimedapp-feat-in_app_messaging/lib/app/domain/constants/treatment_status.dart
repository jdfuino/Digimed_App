//enum for status of treatment

enum TreatmentStatus {
  pendingToStart('pending_initiation'),
  inProgress('progress'),
  completed('finished'),
  paused('paused'),;

  final String value;
  const TreatmentStatus(this.value);

  static TreatmentStatus fromString(String value) {
    return TreatmentStatus.values.firstWhere(
      (e) => e.value == value,
      orElse: () => TreatmentStatus.pendingToStart,
    );
  }
}
