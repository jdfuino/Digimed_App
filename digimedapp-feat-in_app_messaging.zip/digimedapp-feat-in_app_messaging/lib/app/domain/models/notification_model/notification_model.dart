import 'package:digimed/app/domain/constants/notification_constants.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:freezed_annotation/freezed_annotation.dart';


part 'notification_model.freezed.dart';
part 'notification_model.g.dart';

@freezed
class NotificationModel with _$NotificationModel {
  const factory NotificationModel({
    required String id,
    required String title,
    required String body,
    @Default({}) Map<String, dynamic> data,
    required NotificationCategory category,
    required DateTime createdAt,
    @Default(false) bool isRead,
    String? imageUrl,
    DateTime? readAt,
    String? notificationType,
    String? targetType,
    String? targetValue,
    String? status,
    DateTime? deliveredAt,
    DateTime? notificationCreatedAt,
  }) = _NotificationModel;

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      _$NotificationModelFromJson(json);

  factory NotificationModel.fromRemoteMessage(RemoteMessage message) {
    return NotificationModel(
      id: message.messageId ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: message.notification?.title ?? 'Nueva notificación',
      body: message.notification?.body ?? '',
      data: message.data,
      category: NotificationCategory.fromString(message.data['category'] ?? 'promotions'),
      createdAt: message.sentTime ?? DateTime.now(),
      imageUrl: message.notification?.android?.imageUrl ?? message.notification?.apple?.imageUrl,
      // Los campos del inbox no están disponibles en RemoteMessage
      notificationType: null,
      targetType: null,
      targetValue: null,
      status: null,
      deliveredAt: null,
      notificationCreatedAt: null,
    );
  }

  // Nuevo factory constructor para datos del inbox
  factory NotificationModel.fromInboxData(Map<String, dynamic> data) {
    return NotificationModel(
      id: data['id'] as String,
      title: data['title'] as String,
      body: data['body'] as String,
      data: (data['data'] as Map<String, dynamic>?) ?? {},
      category: NotificationCategory.fromString(data['category'] as String),
      createdAt: DateTime.parse(data['created_at'] as String),
      isRead: data['is_read'] as bool? ?? false,
      imageUrl: data['image_url'] as String?,
      readAt: data['read_at'] != null
          ? DateTime.parse(data['read_at'] as String)
          : null,
      notificationType: data['notification_type'] as String?,
      targetType: data['target_type'] as String?,
      targetValue: data['target_value'] as String?,
      status: data['status'] as String?,
      deliveredAt: data['delivered_at'] != null
          ? DateTime.parse(data['delivered_at'] as String)
          : null,
      notificationCreatedAt: data['notification_created_at'] != null
          ? DateTime.parse(data['notification_created_at'] as String)
          : null,
    );
  }

  // Helper method para extraer property_id del campo data
  static String? _extractPropertyId(Map<String, dynamic>? data) {
    if (data == null) return null;
    return data['property_id'] as String?;
  }
}