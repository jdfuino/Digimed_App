import 'package:digimed/app/domain/either/either.dart';
import 'package:digimed/app/domain/failures/http_request/http_request_failure.dart';

abstract class InAppMessagingRepository {
  /// Inicializa Firebase In-App Messaging
  /// Configura los listeners de eventos y establece configuraciones básicas
  Future<Either<HttpRequestFailure, bool>> initialize();

  /// Activa un evento personalizado para mostrar mensajes in-app
  /// Los eventos deben estar configurados en Firebase Console
  Future<Either<HttpRequestFailure, bool>> triggerEvent(String eventName);

  /// Suprime temporalmente los mensajes in-app
  /// Útil para controlar cuándo mostrar o no mostrar mensajes
  Future<Either<HttpRequestFailure, bool>> suppressMessages(bool suppress);

  /// Habilita o deshabilita la recolección automática de datos
  /// Controla si Firebase recopila datos de análisis automáticamente
  Future<Either<HttpRequestFailure, bool>> setDataCollectionEnabled(bool enabled);

  /// Eventos predefinidos comunes
  /// Métodos de conveniencia para eventos estándar
  Future<Either<HttpRequestFailure, bool>> triggerAppOpen();
  Future<Either<HttpRequestFailure, bool>> triggerUserEngagement();
  Future<Either<HttpRequestFailure, bool>> triggerLogin();
  Future<Either<HttpRequestFailure, bool>> triggerSignUp();
  Future<Either<HttpRequestFailure, bool>> triggerTutorialComplete();
  Future<Either<HttpRequestFailure, bool>> triggerPurchase();

  /// Eventos específicos de la aplicación médica
  Future<Either<HttpRequestFailure, bool>> triggerAppointmentBooked();
  Future<Either<HttpRequestFailure, bool>> triggerTestResultsViewed();
  Future<Either<HttpRequestFailure, bool>> triggerProfileCompleted();
  Future<Either<HttpRequestFailure, bool>> triggerMedicationReminder();
  Future<Either<HttpRequestFailure, bool>> triggerHealthTipViewed();
}
